# 🔍 PriceHunt — AI Price Comparison App

A full-stack web application that uses an AI agent to compare product prices across multiple shopping platforms in real-time.

## 🏗️ Project Structure

```
pricehunt/
├── backend/                  # Node.js + Express API
│   ├── config/
│   │   └── database.js       # JSON file-based database layer
│   ├── controllers/
│   │   ├── authController.js     # Register, Login, Profile
│   │   ├── searchController.js   # AI agent price search
│   │   ├── wishlistController.js # Save/remove wishlist items
│   │   └── priceController.js    # Price history, alerts, stats
│   ├── middleware/
│   │   └── auth.js           # JWT authentication middleware
│   ├── routes/
│   │   └── index.js          # All API routes
│   ├── .env                  # Environment variables
│   ├── server.js             # Express app entry point
│   └── package.json
├── frontend/
│   └── index.html            # Complete single-file frontend
├── database/
│   └── db.json               # JSON database (auto-created)
└── README.md
```

## 🚀 Quick Start

### 1. Prerequisites
- Node.js 18+ installed
- Anthropic API key (get one at https://console.anthropic.com)

### 2. Setup Backend

```bash
cd backend
npm install
```

Edit `.env` and add your Anthropic API key:
```
ANTHROPIC_API_KEY=sk-ant-your-key-here
```

Start the server:
```bash
npm start
# or for development with auto-reload:
npm run dev
```

Backend runs at: **http://localhost:5000**

### 3. Open Frontend

Simply open `frontend/index.html` in your browser.
> Or use Live Server extension in VS Code for best experience.

## 🌍 Supported Regions & Platforms

| Region | Platforms |
|--------|-----------|
| 🇮🇳 India | Flipkart, Amazon.in, Meesho, Myntra, Snapdeal, Nykaa, Ajio, JioMart |
| 🇺🇸 N. America | Amazon, Walmart, Target, eBay, Best Buy, Costco, Macy's, Wayfair |
| 🇬🇧 UK | Amazon UK, ASOS, Currys, John Lewis, Argos, Tesco, M&S, Next |
| 🇦🇪 Middle East | Amazon.ae, Noon, Namshi, Carrefour, Sharaf DG, Centrepoint, Ounass, LuLu |
| 🇸🇬 SE Asia | Shopee, Lazada, Amazon SG, Zalora, Courts, Harvey Norman, Qoo10, RedMart |

## 📡 API Endpoints

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/auth/register | Create account |
| POST | /api/auth/login | Sign in |
| GET | /api/auth/me | Get current user |
| PUT | /api/auth/profile | Update profile |

### Search
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/search | Run AI price comparison |
| GET | /api/search/history | User's search history |
| GET | /api/search/popular | Top searched products |
| GET | /api/search/regions | Available regions |

### Wishlist
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/wishlist | Get user's wishlist |
| POST | /api/wishlist | Add item |
| DELETE | /api/wishlist/:id | Remove item |

### Prices & Stats
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/prices/history | Price history for a product |
| GET | /api/stats | App-wide statistics |
| POST | /api/alerts | Create price alert |
| GET | /api/alerts | Get user's alerts |

## 🔧 Tech Stack

**Frontend**
- Vanilla HTML/CSS/JavaScript (no framework, no build step)
- Google Fonts (Inter + Space Grotesk)
- Fetch API for HTTP calls

**Backend**
- Node.js + Express.js
- JWT authentication (jsonwebtoken)
- Bcrypt password hashing (bcryptjs)
- Helmet (security headers)
- CORS
- Rate limiting (express-rate-limit)
- Morgan (request logging)

**Database**
- JSON file database (`database/db.json`)
- Full CRUD via `config/database.js`
- Tables: users, searches, wishlist, price_history, alerts

**AI Agent**
- Anthropic Claude API (claude-sonnet-4-6)
- Generates realistic price comparisons per platform
- Returns structured JSON with prices, ratings, delivery, badges

## 🔐 Environment Variables

```env
PORT=5000
JWT_SECRET=your_secret_key_change_in_production
JWT_EXPIRES_IN=7d
ANTHROPIC_API_KEY=sk-ant-your-key-here
NODE_ENV=development
FRONTEND_URL=http://localhost:3000
```

## 🛠️ To Upgrade for Production

1. **Replace JSON DB** with PostgreSQL or MongoDB
2. **Add real platform APIs**: Flipkart Affiliate, Amazon PA API
3. **Deploy backend** to Railway, Render, or Heroku
4. **Deploy frontend** to Vercel or Netlify
5. **Add email alerts** for price drops using SendGrid/Resend
6. **Add caching** with Redis to reduce API calls

## 📱 Features

- ✅ User registration & login (JWT auth)
- ✅ AI-powered price comparison across 8 platforms
- ✅ 5 regions (India, USA, UK, Middle East, SE Asia)
- ✅ Sort by price, discount, rating, delivery speed
- ✅ Wishlist (save favorite products)
- ✅ Search history (per user)
- ✅ Dashboard with stats
- ✅ Profile management
- ✅ Part number / SKU display
- ✅ Free shipping & stock badges
- ✅ Agent activity log (live)
- ✅ Rate limiting & security headers
- ✅ Mobile responsive

---
Built with ❤️ using Node.js + Anthropic Claude API

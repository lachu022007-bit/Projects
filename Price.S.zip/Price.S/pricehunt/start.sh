#!/bin/bash
echo "🔍 Starting PriceHunt..."
echo ""

# Check Node
if ! command -v node &> /dev/null; then
  echo "❌ Node.js not found. Install from https://nodejs.org"
  exit 1
fi

echo "✓ Node.js $(node -v) found"

# Check .env
if [ ! -f "backend/.env" ]; then
  echo "⚠️  No .env file found. Copying from .env.example..."
  cp backend/.env.example backend/.env
  echo "   → Edit backend/.env and add your ANTHROPIC_API_KEY"
fi

# Install deps
echo "📦 Installing backend dependencies..."
cd backend && npm install --silent
cd ..

echo ""
echo "🚀 Starting backend on http://localhost:5000"
echo "🌐 Open frontend/index.html in your browser"
echo ""
echo "Press Ctrl+C to stop."
echo ""

cd backend && node server.js

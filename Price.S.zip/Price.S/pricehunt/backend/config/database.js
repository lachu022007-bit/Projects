const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('crypto').randomUUID ? { v4: () => require('crypto').randomUUID() } : require('crypto');

const DB_PATH = path.join(__dirname, '../../database/db.json');

function readDB() {
  try {
    const data = fs.readFileSync(DB_PATH, 'utf8');
    return JSON.parse(data);
  } catch {
    return { users: [], searches: [], wishlist: [], price_history: [], alerts: [] };
  }
}

function writeDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
}

const db = {
  // ── USERS ──
  users: {
    findAll: () => readDB().users,
    findById: (id) => readDB().users.find(u => u.id === id),
    findByEmail: (email) => readDB().users.find(u => u.email === email.toLowerCase()),
    create: (data) => {
      const store = readDB();
      const user = { id: generateId(), ...data, email: data.email.toLowerCase(), createdAt: new Date().toISOString() };
      store.users.push(user);
      writeDB(store);
      return user;
    },
    update: (id, data) => {
      const store = readDB();
      const idx = store.users.findIndex(u => u.id === id);
      if (idx === -1) return null;
      store.users[idx] = { ...store.users[idx], ...data, updatedAt: new Date().toISOString() };
      writeDB(store);
      return store.users[idx];
    },
    delete: (id) => {
      const store = readDB();
      store.users = store.users.filter(u => u.id !== id);
      writeDB(store);
    }
  },

  // ── SEARCHES ──
  searches: {
    findAll: () => readDB().searches,
    findByUser: (userId) => readDB().searches.filter(s => s.userId === userId).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)),
    findById: (id) => readDB().searches.find(s => s.id === id),
    create: (data) => {
      const store = readDB();
      const search = { id: generateId(), ...data, createdAt: new Date().toISOString() };
      store.searches.push(search);
      writeDB(store);
      return search;
    },
    getPopular: (limit = 10) => {
      const store = readDB();
      const counts = {};
      store.searches.forEach(s => { counts[s.query] = (counts[s.query] || 0) + 1; });
      return Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, limit).map(([query, count]) => ({ query, count }));
    }
  },

  // ── WISHLIST ──
  wishlist: {
    findByUser: (userId) => readDB().wishlist.filter(w => w.userId === userId),
    findOne: (userId, productId) => readDB().wishlist.find(w => w.userId === userId && w.productId === productId),
    create: (data) => {
      const store = readDB();
      const item = { id: generateId(), ...data, createdAt: new Date().toISOString() };
      store.wishlist.push(item);
      writeDB(store);
      return item;
    },
    delete: (id) => {
      const store = readDB();
      store.wishlist = store.wishlist.filter(w => w.id !== id);
      writeDB(store);
    },
    deleteByUser: (userId, productId) => {
      const store = readDB();
      store.wishlist = store.wishlist.filter(w => !(w.userId === userId && w.productId === productId));
      writeDB(store);
    }
  },

  // ── PRICE HISTORY ──
  priceHistory: {
    findByQuery: (query, region) => readDB().price_history.filter(p => p.query === query && p.region === region),
    create: (data) => {
      const store = readDB();
      const entry = { id: generateId(), ...data, createdAt: new Date().toISOString() };
      store.price_history.push(entry);
      writeDB(store);
      return entry;
    },
    getRecent: (limit = 50) => {
      const store = readDB();
      return store.price_history.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, limit);
    }
  },

  // ── ALERTS ──
  alerts: {
    findByUser: (userId) => readDB().alerts.filter(a => a.userId === userId),
    create: (data) => {
      const store = readDB();
      const alert = { id: generateId(), ...data, triggered: false, createdAt: new Date().toISOString() };
      store.alerts.push(alert);
      writeDB(store);
      return alert;
    },
    delete: (id) => {
      const store = readDB();
      store.alerts = store.alerts.filter(a => a.id !== id);
      writeDB(store);
    },
    trigger: (id) => {
      const store = readDB();
      const idx = store.alerts.findIndex(a => a.id === id);
      if (idx !== -1) { store.alerts[idx].triggered = true; store.alerts[idx].triggeredAt = new Date().toISOString(); writeDB(store); }
    }
  }
};

module.exports = db;

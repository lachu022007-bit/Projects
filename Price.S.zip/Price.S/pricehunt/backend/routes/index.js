const express = require('express');
const router = express.Router();
const { protect, optionalAuth } = require('../middleware/auth');

const auth = require('../controllers/authController');
const search = require('../controllers/searchController');
const wishlist = require('../controllers/wishlistController');
const price = require('../controllers/priceController');

// ── AUTH ──
router.post('/auth/register', auth.register);
router.post('/auth/login', auth.login);
router.get('/auth/me', protect, auth.getMe);
router.put('/auth/profile', protect, auth.updateProfile);

// ── SEARCH ──
router.get('/search/regions', search.getRegions);
router.get('/search/popular', search.getPopular);
router.get('/search/history', protect, search.getHistory);
router.get('/search/:id', search.getSearch);
router.post('/search', optionalAuth, search.search);

// ── WISHLIST ──
router.get('/wishlist', protect, wishlist.getWishlist);
router.post('/wishlist', protect, wishlist.addToWishlist);
router.delete('/wishlist/:id', protect, wishlist.removeFromWishlist);

// ── PRICES & ALERTS ──
router.get('/prices/history', price.getPriceHistory);
router.get('/prices/recent', price.getRecentPrices);
router.get('/alerts', protect, price.getAlerts);
router.post('/alerts', protect, price.createAlert);
router.delete('/alerts/:id', protect, price.deleteAlert);
router.get('/stats', price.getStats);

module.exports = router;

const db = require('../config/database');

// GET /api/prices/history?query=&region=
exports.getPriceHistory = (req, res) => {
  try {
    const { query, region = 'IN' } = req.query;
    if (!query) return res.status(400).json({ success: false, message: 'Query is required.' });
    const history = db.priceHistory.findByQuery(query, region);
    res.json({ success: true, history });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error fetching price history.' });
  }
};

// GET /api/prices/recent
exports.getRecentPrices = (req, res) => {
  try {
    const recent = db.priceHistory.getRecent(30);
    res.json({ success: true, recent });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error fetching recent prices.' });
  }
};

// GET /api/alerts
exports.getAlerts = (req, res) => {
  try {
    const alerts = db.alerts.findByUser(req.user.id);
    res.json({ success: true, alerts });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error fetching alerts.' });
  }
};

// POST /api/alerts
exports.createAlert = (req, res) => {
  try {
    const { productName, platform, targetPrice, currentPrice, currency, region } = req.body;
    if (!productName || !targetPrice) return res.status(400).json({ success: false, message: 'Product name and target price required.' });
    const alert = db.alerts.create({ userId: req.user.id, productName, platform, targetPrice: Number(targetPrice), currentPrice: Number(currentPrice || 0), currency, region });
    res.status(201).json({ success: true, alert });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error creating alert.' });
  }
};

// DELETE /api/alerts/:id
exports.deleteAlert = (req, res) => {
  try {
    db.alerts.delete(req.params.id);
    res.json({ success: true, message: 'Alert deleted.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error deleting alert.' });
  }
};

// GET /api/stats  (dashboard stats)
exports.getStats = (req, res) => {
  try {
    const allSearches = db.searches.findAll();
    const allHistory = db.priceHistory.getRecent(1000);
    const totalSearches = allSearches.length;
    const uniqueQueries = new Set(allSearches.map(s => s.query)).size;
    const totalSaved = allHistory.length;
    const popular = db.searches.getPopular(5);
    res.json({ success: true, stats: { totalSearches, uniqueQueries, totalSaved, popular } });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error fetching stats.' });
  }
};

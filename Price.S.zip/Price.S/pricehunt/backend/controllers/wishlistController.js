const db = require('../config/database');

// GET /api/wishlist
exports.getWishlist = (req, res) => {
  try {
    const items = db.wishlist.findByUser(req.user.id);
    res.json({ success: true, items });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error fetching wishlist.' });
  }
};

// POST /api/wishlist
exports.addToWishlist = (req, res) => {
  try {
    const { productName, platform, price, currency, region, searchId, partNumber } = req.body;
    if (!productName || !platform || !price) {
      return res.status(400).json({ success: false, message: 'Product name, platform, and price are required.' });
    }
    const productId = `${platform}-${productName}`.toLowerCase().replace(/\s+/g, '-');
    const existing = db.wishlist.findOne(req.user.id, productId);
    if (existing) return res.status(409).json({ success: false, message: 'Already in wishlist.' });
    const item = db.wishlist.create({ userId: req.user.id, productId, productName, platform, price, currency, region, searchId, partNumber });
    res.status(201).json({ success: true, item });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error adding to wishlist.' });
  }
};

// DELETE /api/wishlist/:id
exports.removeFromWishlist = (req, res) => {
  try {
    db.wishlist.delete(req.params.id);
    res.json({ success: true, message: 'Removed from wishlist.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error removing from wishlist.' });
  }
};

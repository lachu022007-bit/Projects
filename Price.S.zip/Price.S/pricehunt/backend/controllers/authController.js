const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/database');

const signToken = (id) => jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });

// POST /api/auth/register
exports.register = async (req, res) => {
  try {
    const { name, email, password, region = 'IN' } = req.body;
    if (!name || !email || !password) return res.status(400).json({ success: false, message: 'Name, email, and password are required.' });
    if (password.length < 6) return res.status(400).json({ success: false, message: 'Password must be at least 6 characters.' });
    if (db.users.findByEmail(email)) return res.status(409).json({ success: false, message: 'Email already registered.' });
    const hashedPwd = await bcrypt.hash(password, 12);
    const user = db.users.create({ name: name.trim(), email, password: hashedPwd, region, avatar: name.trim()[0].toUpperCase() });
    const { password: _, ...safeUser } = user;
    res.status(201).json({ success: true, token: signToken(user.id), user: safeUser });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error.', error: err.message });
  }
};

// POST /api/auth/login
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ success: false, message: 'Email and password required.' });
    const user = db.users.findByEmail(email);
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }
    const { password: _, ...safeUser } = user;
    res.json({ success: true, token: signToken(user.id), user: safeUser });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error.', error: err.message });
  }
};

// GET /api/auth/me
exports.getMe = (req, res) => {
  res.json({ success: true, user: req.user });
};

// PUT /api/auth/profile
exports.updateProfile = async (req, res) => {
  try {
    const { name, region, currentPassword, newPassword } = req.body;
    const user = db.users.findById(req.user.id);
    const updates = {};
    if (name) updates.name = name.trim();
    if (region) updates.region = region;
    if (currentPassword && newPassword) {
      if (!(await bcrypt.compare(currentPassword, user.password))) {
        return res.status(400).json({ success: false, message: 'Current password is incorrect.' });
      }
      updates.password = await bcrypt.hash(newPassword, 12);
    }
    const updated = db.users.update(req.user.id, updates);
    const { password: _, ...safeUser } = updated;
    res.json({ success: true, user: safeUser });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error.', error: err.message });
  }
};

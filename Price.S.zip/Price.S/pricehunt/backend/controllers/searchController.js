const db = require('../config/database');

const REGIONS = {
  IN:  { name: 'India',          currency: '₹',   gl: 'in', hl: 'en', platforms: ['Flipkart','Amazon.in','Meesho','Myntra','Snapdeal','Nykaa','Ajio','JioMart'] },
  US:  { name: 'North America',  currency: '$',   gl: 'us', hl: 'en', platforms: ['Amazon','Walmart','Target','eBay','Best Buy','Costco',"Macy's",'Wayfair'] },
  UK:  { name: 'United Kingdom', currency: '£',   gl: 'uk', hl: 'en', platforms: ['Amazon UK','ASOS','Currys','John Lewis','Argos','Tesco','Marks & Spencer','Next'] },
  AE:  { name: 'Middle East',    currency: 'AED', gl: 'ae', hl: 'en', platforms: ['Amazon.ae','Noon','Namshi','Carrefour','Sharaf DG','Centrepoint','Ounass','LuLu'] },
  SG:  { name: 'Southeast Asia', currency: 'SGD', gl: 'sg', hl: 'en', platforms: ['Shopee','Lazada','Amazon SG','Zalora','Courts','Harvey Norman','Qoo10','RedMart'] }
};

const PLATFORM_DOMAINS = {
  'Flipkart':'flipkart.com','Amazon.in':'amazon.in','Meesho':'meesho.com',
  'Myntra':'myntra.com','Snapdeal':'snapdeal.com','Nykaa':'nykaa.com',
  'Ajio':'ajio.com','JioMart':'jiomart.com','Amazon':'amazon.com',
  'Walmart':'walmart.com','Target':'target.com','eBay':'ebay.com',
  'Best Buy':'bestbuy.com','Costco':'costco.com',"Macy's":'macys.com',
  'Wayfair':'wayfair.com','Amazon UK':'amazon.co.uk','ASOS':'asos.com',
  'Currys':'currys.co.uk','John Lewis':'johnlewis.com','Argos':'argos.co.uk',
  'Tesco':'tesco.com','Marks & Spencer':'marksandspencer.com','Next':'next.co.uk',
  'Amazon.ae':'amazon.ae','Noon':'noon.com','Namshi':'namshi.com',
  'Carrefour':'carrefour.ae','Sharaf DG':'sharafdg.com','Centrepoint':'centrepoint.com',
  'Ounass':'ounass.com','LuLu':'luluhypermarket.com','Shopee':'shopee.sg',
  'Lazada':'lazada.sg','Amazon SG':'amazon.sg','Zalora':'zalora.com.sg',
  'Courts':'courts.com.sg','Harvey Norman':'harveynorman.com.sg',
  'Qoo10':'qoo10.sg','RedMart':'redmart.lazada.sg'
};

function parsePrice(str) {
  if (!str) return null;
  const n = parseFloat(String(str).replace(/[^0-9.]/g, ''));
  return isNaN(n) ? null : n;
}

function matchPlatform(item, platforms) {
  const source = (item.source || '').toLowerCase();
  const link   = (item.link   || '').toLowerCase();
  for (const plat of platforms) {
    const domain = (PLATFORM_DOMAINS[plat] || '').toLowerCase();
    if (!domain) continue;
    const base = domain.split('.')[0];
    if (source.includes(base) || link.includes(base)) return plat;
  }
  return null;
}

// ── DEMO FALLBACK (no API key needed) ──
function generateDemoResults(query, reg, platforms) {
  const basePrice = Math.floor(Math.random() * 20000) + 500;
  const icons = ['📱','👗','👟','💻','🎧','📺','🏷️','🛍️'];
  return platforms.map((plat, i) => {
    const variation = 0.75 + Math.random() * 0.5;
    const price = Math.round(basePrice * variation);
    const origPrice = Math.round(price * (1 + Math.random() * 0.4));
    const ratings = [4.1, 4.3, 3.9, 4.5, 4.2, 3.8, 4.4, 4.0];
    const reviews = Math.floor(Math.random() * 50000) + 100;
    const deliveries = ['Same day','Next day','2 days','3-5 days','5-7 days'];
    const badges = ['Best Seller','Deal of the Day','New Arrival','Limited Stock', null, null];
    return {
      platform:      plat,
      productName:   `${query} — ${plat} Edition`,
      price,
      originalPrice: origPrice,
      rating:        ratings[i % ratings.length],
      reviews,
      delivery:      deliveries[i % deliveries.length],
      inStock:       Math.random() > 0.1,
      badge:         badges[i % badges.length],
      freeShipping:  Math.random() > 0.5,
      partNumber:    `${plat.substring(0,3).toUpperCase()}-${Date.now().toString(36).toUpperCase()}`,
      thumbnail:     null,
      link:          `https://www.google.com/search?q=${encodeURIComponent(query+' '+plat)}`,
      source:        'demo'
    };
  });
}

// ── SERP API ──
async function fetchSerpResults(query, reg) {
  const apiKey = process.env.SERP_API_KEY;
  const url = new URL('https://serpapi.com/search');
  url.searchParams.set('engine',  'google_shopping');
  url.searchParams.set('q',       query);
  url.searchParams.set('gl',      reg.gl);
  url.searchParams.set('hl',      reg.hl);
  url.searchParams.set('num',     '40');
  url.searchParams.set('api_key', apiKey);

  console.log(`🔍 SERP API call: ${url.toString().replace(apiKey, 'HIDDEN')}`);

  const res = await fetch(url.toString());
  const text = await res.text();

  if (!res.ok) {
    console.error('SERP API response:', text.substring(0, 300));
    throw new Error(`SERP API error ${res.status}: ${text.substring(0, 150)}`);
  }

  let data;
  try { data = JSON.parse(text); }
  catch(e) { throw new Error('SERP API returned invalid JSON: ' + text.substring(0, 100)); }

  if (data.error) throw new Error('SERP API: ' + data.error);

  return data.shopping_results || [];
}

// POST /api/search
exports.search = async (req, res) => {
  try {
    const { query, region = 'IN', platforms } = req.body;
    if (!query || query.trim().length < 2) {
      return res.status(400).json({ success: false, message: 'Search query must be at least 2 characters.' });
    }

    const reg = REGIONS[region] || REGIONS['IN'];
    const selectedPlatforms = (platforms && platforms.length) ? platforms : reg.platforms;
    const q = query.trim();
    const serpKey = process.env.SERP_API_KEY;
    const hasKey  = serpKey && serpKey !== 'your_serp_api_key_here' && serpKey.length > 10;

    let results = [];
    let dataSource = 'demo';

    if (hasKey) {
      // ── REAL MODE: SERP API ──
      console.log(`🌐 Real mode — SERP API search: "${q}"`);
      try {
        const serpItems = await fetchSerpResults(q, reg);
        console.log(`📦 SERP returned ${serpItems.length} items`);

        const platformMap = {};
        for (const item of serpItems) {
          const plat = matchPlatform(item, selectedPlatforms);
          if (plat && !platformMap[plat]) platformMap[plat] = item;
        }

        for (const plat of selectedPlatforms) {
          const item = platformMap[plat];
          if (item) {
            const price     = parsePrice(item.price) || parsePrice(item.extracted_price);
            const origPrice = parsePrice(item.original_price) || price;
            results.push({
              platform:      plat,
              productName:   (item.title || q).substring(0, 70),
              price:         price || 0,
              originalPrice: origPrice || price || 0,
              rating:        item.rating || null,
              reviews:       item.reviews || null,
              delivery:      item.delivery || 'Check website',
              inStock:       true,
              badge:         item.badge || null,
              freeShipping:  (item.delivery || '').toLowerCase().includes('free'),
              partNumber:    item.product_id || null,
              thumbnail:     item.thumbnail || null,
              link:          item.link || null,
              source:        'serpapi'
            });
          } else {
            results.push({
              platform: plat, productName: `${q} — not listed on ${plat}`,
              price: null, originalPrice: null, rating: null, reviews: null,
              delivery: 'N/A', inStock: false, badge: null, freeShipping: false,
              partNumber: null, thumbnail: null, link: null, source: 'serpapi'
            });
          }
        }
        dataSource = 'serpapi';
      } catch (serpErr) {
        console.error('SERP API failed, falling back to demo:', serpErr.message);
        results = generateDemoResults(q, reg, selectedPlatforms);
        dataSource = 'demo_fallback';
      }
    } else {
      // ── DEMO MODE: no API key ──
      console.log(`🎭 Demo mode — no SERP API key set`);
      results = generateDemoResults(q, reg, selectedPlatforms);
      dataSource = 'demo';
    }

    const found = results.filter(r => r.inStock && r.price);

    // Save to DB
    const searchRecord = db.searches.create({
      query: q, region, userId: req.user?.id || null,
      resultCount: found.length, results: found
    });

    found.forEach(r => {
      db.priceHistory.create({
        query: q, region, platform: r.platform,
        price: r.price, currency: reg.currency, productName: r.productName
      });
    });

    console.log(`✅ Search done — ${found.length} results (source: ${dataSource})`);

    res.json({
      success: true, searchId: searchRecord.id, query: q,
      region, currency: reg.currency, results: found,
      totalFound: found.length, source: dataSource,
      demoMode: dataSource.includes('demo')
    });

  } catch (err) {
    console.error('Search error:', err.message);
    res.status(500).json({ success: false, message: err.message || 'Search failed.' });
  }
};

// GET /api/search/history
exports.getHistory = (req, res) => {
  try {
    const searches = req.user?.id ? db.searches.findByUser(req.user.id).slice(0, 20) : [];
    res.json({ success: true, searches });
  } catch (err) { res.status(500).json({ success: false, message: 'Error.' }); }
};

// GET /api/search/popular
exports.getPopular = (req, res) => {
  try { res.json({ success: true, popular: db.searches.getPopular(12) }); }
  catch (err) { res.status(500).json({ success: false, message: 'Error.' }); }
};

// GET /api/search/:id
exports.getSearch = (req, res) => {
  const s = db.searches.findById(req.params.id);
  if (!s) return res.status(404).json({ success: false, message: 'Not found.' });
  res.json({ success: true, search: s });
};

// GET /api/search/regions
exports.getRegions = (req, res) => {
  res.json({ success: true, regions: REGIONS });
};

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const path = require('path');

const routes = require('./routes/index');

const app = express();

// ── SECURITY ──
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({
  origin: '*',
  credentials: true
}));

// ── RATE LIMITING ──
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 200 });
const searchLimiter = rateLimit({ windowMs: 60 * 1000, max: 20 });
app.use('/api/', limiter);
app.use('/api/search', searchLimiter);

// ── BODY PARSING ──
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(morgan('dev'));

// ── API ROUTES ──
app.use('/api', routes);

// ── HEALTH CHECK ──
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString(), serpApi: !!process.env.SERP_API_KEY });
});

// ── ROOT ──
app.get('/', (req, res) => {
  res.json({ message: 'PriceHunt API is running!', health: 'http://localhost:5000/health' });
});

// ── ERROR HANDLER ──
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ success: false, message: err.message || 'Internal server error.' });
});

app.use((req, res) => res.status(404).json({ success: false, message: 'Route not found.' }));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`\n🚀 PriceHunt backend running on http://localhost:${PORT}`);
  console.log(`📦 Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`🔑 JWT configured: ${!!process.env.JWT_SECRET}`);
  console.log(`🔍 SERP API: ${process.env.SERP_API_KEY && process.env.SERP_API_KEY !== 'your_serp_api_key_here' ? '✓ configured' : '⚠ not set — add SERP_API_KEY to .env'}`);
  console.log(`\n✅ Server is ready! Open frontend/index.html in your browser.\n`);
});

const db = require('../config/database');

const REGIONS = {
  IN:  { name: 'India',          currency: '₹',   countryCode: 'in', gl: 'in', hl: 'en', platforms: ['Flipkart','Amazon.in','Meesho','Myntra','Snapdeal','Nykaa','Ajio','JioMart'] },
  US:  { name: 'North America',  currency: '$',   countryCode: 'us', gl: 'us', hl: 'en', platforms: ['Amazon','Walmart','Target','eBay','Best Buy','Costco',"Macy's",'Wayfair'] },
  UK:  { name: 'United Kingdom', currency: '£',   countryCode: 'uk', gl: 'uk', hl: 'en', platforms: ['Amazon UK','ASOS','Currys','John Lewis','Argos','Tesco','Marks & Spencer','Next'] },
  AE:  { name: 'Middle East',    currency: 'AED', countryCode: 'ae', gl: 'ae', hl: 'en', platforms: ['Amazon.ae','Noon','Namshi','Carrefour','Sharaf DG','Centrepoint','Ounass','LuLu'] },
  SG:  { name: 'Southeast Asia', currency: 'SGD', countryCode: 'sg', gl: 'sg', hl: 'en', platforms: ['Shopee','Lazada','Amazon SG','Zalora','Courts','Harvey Norman','Qoo10','RedMart'] }
};

// Map platform names to their domains for filtering
const PLATFORM_DOMAINS = {
  'Flipkart':         'flipkart.com',
  'Amazon.in':        'amazon.in',
  'Meesho':           'meesho.com',
  'Myntra':           'myntra.com',
  'Snapdeal':         'snapdeal.com',
  'Nykaa':            'nykaa.com',
  'Ajio':             'ajio.com',
  'JioMart':          'jiomart.com',
  'Amazon':           'amazon.com',
  'Walmart':          'walmart.com',
  'Target':           'target.com',
  'eBay':             'ebay.com',
  'Best Buy':         'bestbuy.com',
  'Costco':           'costco.com',
  "Macy's":           'macys.com',
  'Wayfair':          'wayfair.com',
  'Amazon UK':        'amazon.co.uk',
  'ASOS':             'asos.com',
  'Currys':           'currys.co.uk',
  'John Lewis':       'johnlewis.com',
  'Argos':            'argos.co.uk',
  'Tesco':            'tesco.com',
  'Marks & Spencer':  'marksandspencer.com',
  'Next':             'next.co.uk',
  'Amazon.ae':        'amazon.ae',
  'Noon':             'noon.com',
  'Namshi':           'namshi.com',
  'Carrefour':        'carrefour.ae',
  'Sharaf DG':        'sharafdg.com',
  'Centrepoint':      'centrepoint.com',
  'Ounass':           'ounass.com',
  'LuLu':             'luluhypermarket.com',
  'Shopee':           'shopee.sg',
  'Lazada':           'lazada.sg',
  'Amazon SG':        'amazon.sg',
  'Zalora':           'zalora.com.sg',
  'Courts':           'courts.com.sg',
  'Harvey Norman':    'harveynorman.com.sg',
  'Qoo10':            'qoo10.sg',
  'RedMart':          'redmart.lazada.sg'
};

// Fetch real prices from SERP API Google Shopping
async function fetchSerpPrices(query, reg) {
  const apiKey = process.env.SERP_API_KEY;
  if (!apiKey) throw new Error('SERP_API_KEY not set in .env');

  const url = new URL('https://serpapi.com/search');
  url.searchParams.set('engine', 'google_shopping');
  url.searchParams.set('q', query);
  url.searchParams.set('gl', reg.gl);
  url.searchParams.set('hl', reg.hl);
  url.searchParams.set('api_key', apiKey);
  url.searchParams.set('num', '40');

  const res = await fetch(url.toString());
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`SERP API error: ${res.status} - ${err}`);
  }
  const data = await res.json();
  return data.shopping_results || [];
}

// Match SERP result to a known platform
function matchPlatform(result, selectedPlatforms) {
  const source = (result.source || '').toLowerCase();
  const link   = (result.link   || '').toLowerCase();
  for (const plat of selectedPlatforms) {
    const domain = (PLATFORM_DOMAINS[plat] || '').toLowerCase();
    if (!domain) continue;
    const domainBase = domain.replace('www.', '').split('.')[0];
    if (source.includes(domainBase) || link.includes(domainBase)) {
      return plat;
    }
  }
  return null;
}

// Parse price string like "₹1,299" or "$29.99" to number
function parsePrice(priceStr) {
  if (!priceStr) return null;
  const cleaned = String(priceStr).replace(/[^0-9.]/g, '');
  const num = parseFloat(cleaned);
  return isNaN(num) ? null : num;
}

// POST /api/search
exports.search = async (req, res) => {
  try {
    const { query, region = 'IN', platforms } = req.body;
    if (!query || query.trim().length < 2) {
      return res.status(400).json({ success: false, message: 'Search query must be at least 2 characters.' });
    }

    const reg = REGIONS[region] || REGIONS['IN'];
    const selectedPlatforms = platforms && platforms.length ? platforms : reg.platforms;

    console.log(`🔍 Searching SERP API: "${query}" in ${reg.name}`);

    // Fetch from SERP API
    const serpResults = await fetchSerpPrices(query.trim(), reg);
    console.log(`📦 SERP API returned ${serpResults.length} raw results`);

    // Match results to platforms
    const platformMap = {};   // platform -> best result
    const unmatchedResults = [];

    for (const item of serpResults) {
      const platform = matchPlatform(item, selectedPlatforms);
      if (platform) {
        // Keep lowest price per platform
        if (!platformMap[platform]) {
          platformMap[platform] = item;
        }
      } else {
        unmatchedResults.push(item);
      }
    }

    // Build final results array
    const results = [];

    for (const plat of selectedPlatforms) {
      const item = platformMap[plat];
      if (item) {
        const price = parsePrice(item.price);
        const origPrice = parsePrice(item.extracted_price) || price;
        results.push({
          platform:      plat,
          productName:   item.title ? item.title.substring(0, 70) : query,
          price:         price || 0,
          originalPrice: origPrice || price || 0,
          rating:        item.rating || null,
          reviews:       item.reviews || null,
          delivery:      item.delivery || 'Check website',
          inStock:       true,
          badge:         item.badge || null,
          freeShipping:  (item.delivery || '').toLowerCase().includes('free'),
          partNumber:    item.product_id || null,
          thumbnail:     item.thumbnail || null,
          link:          item.link || null,
          source:        item.source || plat
        });
      } else {
        // Platform not found in SERP results — mark as not found
        results.push({
          platform:      plat,
          productName:   `${query} — not found`,
          price:         null,
          originalPrice: null,
          rating:        null,
          reviews:       null,
          delivery:      'N/A',
          inStock:       false,
          badge:         null,
          freeShipping:  false,
          partNumber:    null,
          thumbnail:     null,
          link:          null,
          source:        plat
        });
      }
    }

    // Filter to only in-stock (found) results
    const foundResults = results.filter(r => r.inStock && r.price !== null);
    const allResults   = results; // keep all for transparency

    console.log(`✅ Matched ${foundResults.length}/${selectedPlatforms.length} platforms`);

    // Save search to DB
    const searchRecord = db.searches.create({
      query:       query.trim(),
      region,
      userId:      req.user?.id || null,
      resultCount: foundResults.length,
      results:     foundResults
    });

    // Save price history
    foundResults.forEach(r => {
      db.priceHistory.create({
        query:       query.trim(),
        region,
        platform:    r.platform,
        price:       r.price,
        currency:    reg.currency,
        productName: r.productName
      });
    });

    res.json({
      success:   true,
      searchId:  searchRecord.id,
      query:     query.trim(),
      region,
      currency:  reg.currency,
      results:   foundResults,
      allResults,
      totalFound: foundResults.length,
      source:    'serpapi'
    });

  } catch (err) {
    console.error('Search error:', err.message);
    res.status(500).json({ success: false, message: 'Search failed.', error: err.message });
  }
};

// GET /api/search/history
exports.getHistory = (req, res) => {
  try {
    const userId  = req.user?.id;
    const searches = userId ? db.searches.findByUser(userId).slice(0, 20) : [];
    res.json({ success: true, searches });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error fetching history.' });
  }
};

// GET /api/search/popular
exports.getPopular = (req, res) => {
  try {
    const popular = db.searches.getPopular(12);
    res.json({ success: true, popular });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Error fetching popular searches.' });
  }
};

// GET /api/search/:id
exports.getSearch = (req, res) => {
  const search = db.searches.findById(req.params.id);
  if (!search) return res.status(404).json({ success: false, message: 'Search not found.' });
  res.json({ success: true, search });
};

// GET /api/search/regions
exports.getRegions = (req, res) => {
  res.json({ success: true, regions: REGIONS });
};

// ---- login/register page ----
let isRegisterMode = false;

function toggleAuthMode(){
  isRegisterMode = !isRegisterMode;
  document.getElementById('authTitle').textContent = isRegisterMode ? "Create an account" : "Sign in";
  document.getElementById('authSubmit').textContent = isRegisterMode ? "Register" : "Sign in";
  document.getElementById('authToggleText').textContent = isRegisterMode ? "Already have an account?" : "New here?";
  document.getElementById('authToggleLink').textContent = isRegisterMode ? "Sign in" : "Create an account";
  document.getElementById('authErr').textContent = "";
  document.getElementById('trackField').style.display = isRegisterMode ? 'block' : 'none';
}

async function submitAuth(){
  const email = document.getElementById('authEmail').value.trim();
  const password = document.getElementById('authPassword').value;
  const errEl = document.getElementById('authErr');
  errEl.textContent = "";
  if(!email || !password){ errEl.textContent = "Enter both email and password."; return; }
  try{
    const path = isRegisterMode ? "/api/auth/register" : "/api/auth/login";
    const payload = {email, password};
    if(isRegisterMode){ payload.track = document.getElementById('authTrack').value; }
    const res = await fetch(API + path, {
      method:"POST", headers:{"Content-Type":"application/json"},
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if(!res.ok){ errEl.textContent = data.detail || "Something went wrong."; return; }
    setToken(data.token);
    await routeAfterAuth();
  }catch(e){ errEl.textContent = "Could not reach the server."; }
}

// Where to land after a successful login/register, or on repeat visits to
// login.html while already signed in.
//
// Login always goes straight to the dashboard. Resume upload and the profile
// wizard are no longer blocking onboarding gates — they're reachable any time
// from the sidebar ("Resume") and from the dashboard's "Upload & Analyze
// Resume →" call to action.
async function routeAfterAuth(){
  location.href = 'dashboard.html';
}

// Called on login.html load: if already signed in, skip straight past the login form.
async function redirectIfAlreadyAuthed(){
  if(isLoggedIn()){ await routeAfterAuth(); }
}

// ---- job role picker (shared by resume.html) ----

let selectedJobRole = "";

async function loadJobRoleOptions(){
  const select = el('jobRoleSelect');
  if(!select) return;

  let roles = [];
  let me = null;
  try{
    const [rolesRes, dashRes] = await Promise.all([
      api('/api/job-roles'),
      api('/api/dashboard').catch(()=>null)
    ]);
    roles = rolesRes.roles || [];
    me = dashRes;
  }catch(e){
    return; // role picker is optional — a failed load shouldn't block upload
  }

  // group by track for a friendlier dropdown
  const byTrack = {};
  roles.forEach(r=>{
    (byTrack[r.track_label] = byTrack[r.track_label] || []).push(r);
  });

  let html = '<option value="">Choose a role for an ATS-matched score…</option>';
  Object.keys(byTrack).forEach(trackLabel=>{
    html += `<optgroup label="${trackLabel}">`;
    html += byTrack[trackLabel].map(r =>
      `<option value="${r.role}">${r.role}</option>`
    ).join('');
    html += '</optgroup>';
  });
  select.innerHTML = html;

  if(me && me.target_job){
    select.value = me.target_job;
    selectedJobRole = me.target_job;
  }
}

async function onJobRoleChange(){
  const select = el('jobRoleSelect');
  if(!select) return;
  selectedJobRole = select.value;
  if(!selectedJobRole) return;

  // Persist immediately so the dashboard/roadmap reflect the choice even if
  // the user hasn't uploaded a resume in this session yet.
  try{
    await api('/api/profile/role', {
      method: 'POST',
      body: JSON.stringify({role: selectedJobRole})
    });
  }catch(e){
    const errEl = el('uploadErr');
    if(errEl) errEl.textContent = e.message || 'Could not save that role.';
  }
}


const MAX_RESUME_BYTES = 10 * 1024 * 1024; // 10 MB
const ALLOWED_RESUME_EXT = ['.pdf', '.docx'];

function triggerFileSelect(){
  const input = document.getElementById('resumeFileInput');
  if(input) input.click();
}

function initResumeUpload(){
  const input = document.getElementById('resumeFileInput');
  const dropzone = document.getElementById('dropzone');
  if(!input || !dropzone) return;

  input.addEventListener('change', (e)=>{
    const file = e.target.files && e.target.files[0];
    if(file) handleResumeFile(file);
  });

  // real drag-and-drop support
  ['dragover','dragenter'].forEach(evt=>{
    dropzone.addEventListener(evt, (e)=>{
      e.preventDefault();
      dropzone.style.borderColor = 'var(--ember)';
    });
  });
  ['dragleave','dragend'].forEach(evt=>{
    dropzone.addEventListener(evt, (e)=>{
      e.preventDefault();
      dropzone.style.borderColor = 'var(--panelBorder)';
    });
  });
  dropzone.addEventListener('drop', (e)=>{
    e.preventDefault();
    dropzone.style.borderColor = 'var(--panelBorder)';
    const file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
    if(file) handleResumeFile(file);
  });
}

// Validate on extension + size rather than the browser-reported MIME type,
// which is unreliable across OSes and browsers.
function validateResumeFile(file){
  if(!file) return 'Please select a resume.';
  const name = (file.name || '').toLowerCase();
  const okExt = ALLOWED_RESUME_EXT.some(ext => name.endsWith(ext));
  if(!okExt) return 'Only PDF and DOCX resumes are supported.';
  if(file.size > MAX_RESUME_BYTES) return 'Resume must be smaller than 10 MB.';
  if(file.size === 0) return 'That file is empty. Please select a valid resume.';
  return null;
}

// Small helpers so the stage indicator and progress bar stay in sync.
function setResumeStage(text, pct){
  const label = document.getElementById('stageLabel');
  const fill = document.getElementById('progressFill');
  const bar = document.getElementById('progressBar');
  if(bar) bar.style.display = 'block';
  if(label) label.textContent = text;
  if(fill) fill.style.width = pct + '%';
}

function el(id){ return document.getElementById(id); }

// Renders the ATS keyword-match card. Hides it entirely when no role was
// selected — an ATS score without a target role would be meaningless.
function renderAtsCard(ats, jobRole){
  const card = el('atsCard');
  if(!card) return;

  if(!ats || !jobRole){
    card.style.display = 'none';
    return;
  }

  card.style.display = 'block';

  const roleName = el('atsRoleName');
  if(roleName) roleName.textContent = jobRole;

  const scoreNum = el('atsScoreNum');
  if(scoreNum) scoreNum.textContent = `${ats.score}/100`;

  const bar = el('atsScoreBar');
  if(bar){
    bar.style.width = ats.score + '%';
    bar.style.background = ats.score >= 70 ? 'var(--signal)'
      : ats.score >= 40 ? 'var(--ember)'
      : 'var(--danger)';
  }

  const matched = el('atsMatched');
  if(matched){
    matched.innerHTML = (ats.matched_keywords && ats.matched_keywords.length)
      ? ats.matched_keywords.map(s => `<span class="pill pill-signal">${s}</span>`).join('')
      : '<span class="pill pill-mist">None matched</span>';
  }

  const missing = el('atsMissing');
  if(missing){
    missing.innerHTML = (ats.missing_keywords && ats.missing_keywords.length)
      ? ats.missing_keywords.map(s => `<span class="pill pill-danger">${s}</span>`).join('')
      : '<span class="pill pill-signal">All required keywords present</span>';
  }
}

async function handleResumeFile(file){
  const errEl = el('uploadErr');
  if(errEl){ errEl.textContent = ''; errEl.style.color = ''; }

  const problem = validateResumeFile(file);
  if(problem){
    if(errEl) errEl.textContent = problem;
    return;
  }

  const dropzone = el('dropzone');
  const fileChip = el('fileChip');
  const fileChipName = el('fileChipName');
  const parsedPreview = el('parsedPreview');
  const parsedSkills = el('parsedSkills');
  const continueBtn = el('continueBtn');
  const aiBox = el('resumeAIAnalysis');
  const aiText = el('resumeAIText');
  const aiSourcePill = el('aiSourcePill');

  if(dropzone) dropzone.style.display = 'none';
  if(fileChip) fileChip.style.display = 'flex';
  if(fileChipName) fileChipName.textContent = file.name;
  if(parsedPreview) parsedPreview.style.display = 'none';
  if(aiBox) aiBox.style.display = 'none';
  if(continueBtn) continueBtn.disabled = true;

  setResumeStage('Uploading…', 25);

  try{
    // ---- STEP 1: upload + parse on the backend -----------------------
    const formData = new FormData();
    formData.append('file', file, file.name);
    if(selectedJobRole){
      formData.append('job_role', selectedJobRole);
    }

    setResumeStage('Parsing your resume…', 45);

    const data = await api('/api/onboarding/resume', {
      method: 'POST',
      body: formData
    });

    // ---- STEP 2: show extracted skills + score -----------------------
    setResumeStage('Reading detected skills…', 65);

    if(parsedPreview) parsedPreview.style.display = 'block';

    if(parsedSkills){
      parsedSkills.innerHTML =
        (data.skills && data.skills.length)
          ? data.skills.map(s => `<span class="pill pill-signal">${s}</span>`).join('')
          : '<span class="pill pill-mist">No recognized skills found</span>';
    }

    renderAtsCard(data.ats, data.job_role);

    if(!data.job_role && errEl){
      errEl.style.color = 'var(--mist)';
      errEl.textContent = 'Pick a target job role above and re-upload to get your ATS score.';
    }

    // ---- STEP 3: run the Resume Agent (Coordinator → Groq) -----------
    setResumeStage('Analyzing with AI…', 80);

    if(aiBox) aiBox.style.display = 'block';
    if(aiText) aiText.textContent = 'AI is analyzing your resume…';

    const analysis = await agent('resume');

    if(analysis.ats_score !== undefined && analysis.ats_score !== null){
      renderAtsCard({
        score: analysis.ats_score,
        matched_keywords: analysis.ats_matched_keywords || [],
        missing_keywords: analysis.ats_missing_keywords || []
      }, analysis.target_job);
    }

    // ---- STEP 4: render the analysis ---------------------------------
    renderResumeAnalysis(analysis);

    if(aiSourcePill){
      const groq = analysis.analysis_source === 'groq';
      aiSourcePill.textContent = groq ? 'GROQ AI' : 'AI UNAVAILABLE';
      aiSourcePill.className = groq ? 'pill pill-ember mono' : 'pill pill-mist mono';
    }

    // ---- STEP 5: enable Continue (no automatic redirect) -------------
    setResumeStage('Done', 100);
    if(continueBtn) continueBtn.disabled = false;

  }catch(error){
    console.error('Resume processing error:', error);
    if(errEl){
      errEl.style.color = '';
      errEl.textContent = error.message || 'Could not analyze your resume.';
    }
    resetUpload();
  }
}

// Renders the seven analysis sections when the backend was able to split them,
// falling back to the raw text otherwise.
function renderResumeAnalysis(analysis){
  const aiText = el('resumeAIText');
  if(!aiText) return;

  const sections = analysis.sections || {};
  const order = [
    ['strengths',     'Strengths'],
    ['improvements',  'Improvements'],
    ['missing_skills','Missing Skills'],
    ['ats',           'ATS / Content Improvements'],
    ['projects',      'Project Improvements'],
    ['alignment',     'Career Alignment'],
    ['next_action',   'Next Action']
  ];

  const filled = order.filter(([key]) => sections[key]);

  if(!filled.length){
    aiText.textContent = analysis.analysis || 'No AI analysis was returned.';
    aiText.style.whiteSpace = 'pre-wrap';
    return;
  }

  aiText.style.whiteSpace = 'normal';
  aiText.innerHTML = filled.map(([key, label]) => `
    <div style="margin-bottom:16px;">
      <div class="mono" style="font-size:11px; color:var(--mist); text-transform:uppercase; margin-bottom:6px;">
        ${label}
      </div>
      <div style="font-size:13px; line-height:1.7; white-space:pre-wrap;">${escapeHTML(sections[key])}</div>
    </div>
  `).join('');
}

function escapeHTML(str){
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

async function skipResume(){
  // Guard: if a resume was already successfully parsed on this page, treat
  // "I don't have a resume yet" as a destructive action and confirm first —
  // it's positioned right next to Continue and an accidental click would
  // silently throw away real analysis (score, detected skills, and the
  // personalized roadmap built from them).
  const preview = el('parsedPreview');
  const alreadyParsed = preview && preview.style.display !== 'none';
  if(alreadyParsed){
    const ok = confirm("You already uploaded a resume and it was analyzed successfully. " +
      "Skipping now will discard that analysis and reset your dashboard, skill gap, " +
      "and roadmap to generic defaults. Continue anyway?");
    if(!ok) return;
  }
  try{
    await api('/api/onboarding/resume/skip', {method:'POST'});
  }catch(e){
    const errEl = el('uploadErr');
    if(errEl) errEl.textContent = e.message || 'Could not save that.';
    return;
  }
  location.href = 'dashboard.html';
}

function resetUpload(){
  const dropzone = el('dropzone');
  if(dropzone) dropzone.style.display = 'block';
  ['fileChip','progressBar','parsedPreview','resumeAIAnalysis','atsCard'].forEach(id=>{
    const node = el(id);
    if(node) node.style.display = 'none';
  });
  const fill = el('progressFill');
  if(fill) fill.style.width = '0%';
  const label = el('stageLabel');
  if(label) label.textContent = '';
  const cont = el('continueBtn');
  if(cont) cont.disabled = true;
  const input = el('resumeFileInput');
  if(input) input.value = '';
}

// ---- profile wizard page ----
const qFields=["highest_qualification","degree_branch","institution","graduation_year","current_skills"];
const questions=[
  "What's your highest qualification?","What's your degree and branch?",
  "Which institution do you study at?","What's your graduation year?",
  "What skills do you already have?"
];
let qIndex=0; const qAnswers={};

function renderQ(){
  document.getElementById('qCounter').textContent='Question '+(qIndex+1)+' of '+questions.length;
  document.getElementById('qText').textContent=questions[qIndex];
  document.getElementById('qInput').value = qAnswers[qFields[qIndex]] || "";
  document.getElementById('qProgress').style.width=Math.round(((qIndex+1)/questions.length)*100)+'%';
  document.getElementById('nextBtn').textContent = qIndex===questions.length-1 ? 'Build my profile' : 'Next';
  const errEl = document.getElementById('qError');
  if(errEl) errEl.textContent = "";
}
async function nextQ(){
  const val = document.getElementById('qInput').value.trim();
  if(!val){
    showQError("Please enter an answer before continuing.");
    return;
  }
  qAnswers[qFields[qIndex]] = val;
  if(qIndex<questions.length-1){ qIndex++; renderQ(); }
  else{
    const btn = document.getElementById('nextBtn');
    btn.disabled = true;
    try{
      await agent('profile', qAnswers);
      location.href = 'dashboard.html';
    }catch(e){
      showQError(e.message || "Could not save your profile — please try again.");
      btn.disabled = false;
    }
  }
}
function showQError(msg){
  let el = document.getElementById('qError');
  if(!el){
    el = document.createElement('div');
    el.id = 'qError';
    el.style.cssText = 'color:#ff6b6b; font-size:13px; margin-top:10px;';
    document.getElementById('qInput').insertAdjacentElement('afterend', el);
  }
  el.textContent = msg;
}
function prevQ(){
  if(qIndex>0){ qAnswers[qFields[qIndex]] = document.getElementById('qInput').value; qIndex--; renderQ(); }
  else { location.href = 'resume.html'; }
}

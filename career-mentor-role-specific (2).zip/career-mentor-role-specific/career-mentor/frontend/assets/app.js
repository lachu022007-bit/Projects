// ============================================================
// Career Mentor - Per-page data loaders
// ============================================================
// This file contains the frontend logic for Dashboard, Career,
// Skill Gap, Roadmap, Courses, Projects, Quiz, Interview,
// Progress and Settings pages.
// ============================================================


// ============================================================
// DASHBOARD
// ============================================================

async function loadDashboard() {
  const d = await api('/api/dashboard');

  const readinessNum = document.getElementById('readinessNum');
  const dashMissing = document.getElementById('dashMissing');
  const dashRoadmap = document.getElementById('dashRoadmap');
  const dashTasks = document.getElementById('dashTasks');
  const dashTrail = document.getElementById('dashTrail');
  const dashTrackPill = document.getElementById('dashTrackPill');

  if (readinessNum) {
    readinessNum.textContent = d.readiness + '%';
  }

  // Every resume-derived value below comes from the backend and is only shown
  // once resume_done is true. Nothing here is hardcoded. The dashboard shows
  // only the ATS (role-matched) score — the generic resume-quality score is
  // no longer surfaced in the UI.
  const resumeDone = !!d.resume_done;

  const resumeCtaTitle = document.getElementById('resumeCtaTitle');
  if (resumeCtaTitle) {
    resumeCtaTitle.textContent = resumeDone
      ? 'Resume analyzed'
      : 'Upload your resume';
  }

  const resumeCtaBtn = document.getElementById('resumeCtaBtn');
  if (resumeCtaBtn) {
    resumeCtaBtn.textContent = resumeDone
      ? 'View / re-analyze resume →'
      : 'Upload & Analyze Resume →';
  }

  if (dashMissing) {
    if (!resumeDone) {
      dashMissing.innerHTML =
        '<span style="font-size:13px; color:var(--mist); line-height:1.6;">' +
        'Upload your resume to calculate your personalized skill gap.' +
        '</span>';
    } else {
      dashMissing.innerHTML =
        (d.missing_skills || [])
          .map(
            s => `<span class="pill pill-danger">${s.name}</span>`
          )
          .join('') ||
        '<span style="font-size:13px; color:var(--mist);">' +
        'No major gaps detected for your track.' +
        '</span>';
    }
  }

  const atsScoreNum = document.getElementById('atsScoreNum');
  const atsMissingPreview = document.getElementById('atsMissingPreview');
  const atsScoreLink = document.getElementById('atsScoreLink');
  const dashTargetRolePill = document.getElementById('dashTargetRolePill');

  if (dashTargetRolePill) {
    if (d.target_job) {
      dashTargetRolePill.style.display = 'inline-block';
      dashTargetRolePill.textContent = d.target_job;
    } else {
      dashTargetRolePill.style.display = 'none';
    }
  }

  if (atsScoreNum) {
    if (!d.target_job) {
      atsScoreNum.textContent = 'No role set';
      atsScoreNum.style.fontSize = '18px';
    } else if (typeof d.ats_score === 'number') {
      atsScoreNum.textContent = d.ats_score + '/100';
      atsScoreNum.style.fontSize = '28px';
    } else {
      atsScoreNum.textContent = 'Upload resume';
      atsScoreNum.style.fontSize = '18px';
    }
  }

  if (atsMissingPreview) {
    if (!d.target_job) {
      atsMissingPreview.textContent =
        'Pick a target job role to see how your resume matches its keywords.';
    } else if (typeof d.ats_score === 'number') {
      atsMissingPreview.textContent = (d.ats_missing_keywords || []).length
        ? 'Missing: ' + d.ats_missing_keywords.join(', ')
        : 'All required keywords present.';
    } else {
      atsMissingPreview.textContent =
        'Upload your resume to see your ATS match for ' + d.target_job + '.';
    }
  }

  if (atsScoreLink) {
    atsScoreLink.textContent = d.target_job
      ? (typeof d.ats_score === 'number' ? 'View full analysis →' : 'Upload resume →')
      : 'Choose a target role →';
  }

  if (dashRoadmap) {
    dashRoadmap.textContent =
      `Day ${d.roadmap_progress.done} of ${d.roadmap_progress.total}`;
  }

  if (dashTasks) {
    dashTasks.innerHTML =
      (d.upcoming_tasks || [])
        .map(
          t => `<li>${t.title}</li>`
        )
        .join('') ||
      '<li>No tasks yet — generate a roadmap</li>';
  }

  if (dashTrail) {
    // Stage 0 until a resume is actually analyzed, then advance with roadmap
    // progress — never a fixed "you're already 2 steps in" placeholder.
    const rp = d.roadmap_progress || {done: 0, total: 1};
    let stage = 0;
    if (resumeDone) {
      stage = 2 + Math.min(2, Math.floor(3 * (rp.done / (rp.total || 1))));
    }
    dashTrail.innerHTML = trailHTML(
      stage,
      5,
      ['Resume', 'Skill gap', 'Roadmap', 'Interview', 'Offer']
    );
  }

  if (dashTrackPill) {
    dashTrackPill.textContent = d.track_label || '';
  }
}


// ============================================================
// CAREER
// ============================================================

async function loadCareer() {
  const d = await api('/api/career');

  const note = document.getElementById('careerNote');

  if (note) {
    note.textContent = d.resume_based
      ? 'Ranked from the skills detected on your uploaded resume.'
      : 'Upload your resume to get recommendations tailored to your actual skills.';
  }

  makePager(
    document.getElementById('careerList'),
    document.getElementById('careerPager'),
    d.recommendations || [],
    4,
    r => `
      <div
        class="card"
        style="
          display:flex;
          justify-content:space-between;
          align-items:flex-start;
        "
      >

        <div>

          <div style="font-weight:600; font-size:16px;">
            ${r.role}

            <span
              class="mono"
              style="
                font-size:10px;
                color:var(--mist);
                font-weight:400;
              "
            >
              ${r.track_label || ''}
            </span>
          </div>

          <p
            style="
              font-size:13px;
              color:var(--mist);
              margin:8px 0;
              max-width:460px;
            "
          >
            ${r.why}
          </p>

          <div
            style="
              display:flex;
              gap:6px;
              flex-wrap:wrap;
            "
          >
            ${(r.skills || [])
              .map(
                s => `
                  <span
                    class="pill ${
                      (r.matched_skills || []).includes(s)
                        ? 'pill-signal'
                        : 'pill-mist'
                    }"
                  >
                    ${s}
                  </span>
                `
              )
              .join('')}
          </div>

        </div>

        <div
          class="display"
          style="
            font-size:26px;
            color:${
              r.score > 75
                ? 'var(--ember)'
                : 'var(--mist)'
            };
          "
        >
          ${r.score}%
        </div>

      </div>
    `
  );
}


// ============================================================
// SKILL GAP
// ============================================================

async function loadSkillGap() {
  const d = await agent('skillgap');

  const note = document.getElementById('skillgapNote');

  if (note) {
    note.textContent = d.resume_based
      ? 'Based on the skills detected on your uploaded resume.'
      : 'Upload your resume to calculate your personalized skill gap.';
  }

  const strongSkills =
    document.getElementById('strongSkills');

  const missingSkills =
    document.getElementById('missingSkills');

  const readinessBar =
    document.getElementById('readinessBar');

  const readinessPct =
    document.getElementById('readinessPct');

  if (strongSkills) {
    strongSkills.innerHTML =
      (d.strong_skills || []).length
        ? d.strong_skills
            .map(
              s => `
                <span class="pill pill-signal">
                  ${s}
                </span>
              `
            )
            .join('')
        : '<span class="pill pill-mist">None detected yet</span>';
  }

  if (missingSkills) {
    missingSkills.innerHTML =
      (d.missing_skills || [])
        .map(
          s => `
            <span class="pill pill-danger">
              ${s.name} · ${s.priority}
            </span>
          `
        )
        .join('') ||
      '<span style="font-size:13px; color:var(--mist);">' +
      'Upload your resume to calculate your personalized skill gap.' +
      '</span>';
  }

  if (readinessBar) {
    readinessBar.style.width = d.readiness + '%';
  }

  if (readinessPct) {
    readinessPct.textContent = d.readiness + '%';
  }
}


// ============================================================
// ROADMAP
// ============================================================

// Shows which job role the page's content was built for.
function tagRole(role) {
  const h = document.querySelector('.pagepane h2');
  if (!h || !role) return;
  h.querySelectorAll('.role-tag').forEach(n => n.remove());
  const s = document.createElement('span');
  s.className = 'role-tag mono';
  s.style.cssText = 'font-size:12px; color:var(--mist); margin-left:10px;';
  s.textContent = 'for ' + role;
  h.appendChild(s);
}


async function loadRoadmap() {
  const d = await agent('roadmap');
  tagRole(d.role);

  const weekNums = Object.keys(d.weeks || {});

  const container =
    document.getElementById('roadmapWeeks');

  const pager =
    document.getElementById('roadmapPager');

  makePager(
    container,
    pager,
    weekNums,
    1,
    week => {
      const tasks = d.weeks[week] || [];

      return `
        <div class="card">

          <div
            class="mono"
            style="
              font-size:11px;
              color:var(--mist);
              margin-bottom:10px;
            "
          >
            WEEK ${week}
          </div>

          ${tasks
            .map(
              t => `
                <label
                  style="
                    display:flex;
                    align-items:center;
                    gap:10px;
                    padding:6px 0;
                    font-size:14px;
                    cursor:pointer;
                  "
                >

                  <input
                    type="checkbox"
                    ${t.done ? 'checked' : ''}
                    onchange="toggleTask(${t.id}, this.checked)"
                  >

                  ${t.title}

                </label>
              `
            )
            .join('')}

        </div>
      `;
    }
  );
}


async function toggleTask(id, done) {
  await agent('roadmap', {
    toggle_task_id: id,
    done: done
  });

  // Refresh roadmap after changing task status
  await loadRoadmap();
}


// ============================================================
// COURSES
// ============================================================

async function loadCourses() {
  const d = await api('/api/courses');
  tagRole(d.role);

  makePager(
    document.getElementById('coursesList'),
    document.getElementById('coursesPager'),
    d.courses || [],
    3,
    c => `
      <a
        class="card"
        href="${c.url || '#'}"
        target="_blank"
        rel="noopener"
        style="
          display:block;
          text-decoration:none;
          color:inherit;
          cursor:pointer;
        "
      >

        <span
          class="pill ${
            c.free
              ? 'pill-signal'
              : 'pill-ember'
          }"
        >
          ${c.free ? 'Free' : 'Paid'} · ${c.platform}
        </span>

        <div
          style="
            font-weight:600;
            margin-top:10px;
          "
        >
          ${c.title}
        </div>

        <div
          style="
            font-size:12px;
            color:var(--mist);
            margin-top:4px;
          "
        >
          ${c.duration}
        </div>

      </a>
    `
  );
}


// ============================================================
// PROJECTS
// ============================================================

async function loadProjects() {
  const d = await api('/api/projects');
  tagRole(d.role);

  const lvlClass = {
    Beginner: 'pill-signal',
    Intermediate: 'pill-ember',
    Advanced: 'pill-danger'
  };

  makePager(
    document.getElementById('projectsList'),
    document.getElementById('projectsPager'),
    d.projects || [],
    3,
    p => `
      <a
        class="card"
        href="${p.url || '#'}"
        target="_blank"
        rel="noopener"
        style="
          display:block;
          text-decoration:none;
          color:inherit;
          cursor:pointer;
        "
      >

        <span class="pill ${lvlClass[p.level] || 'pill-mist'}">
          ${p.level}
        </span>

        <div
          style="
            font-weight:600;
            margin-top:10px;
          "
        >
          ${p.title}
        </div>

        <p
          class="display-i"
          style="
            font-size:13px;
            margin-top:8px;
            color:var(--mist);
          "
        >
          "${p.outcome}"
        </p>

      </a>
    `
  );
}


// ============================================================
// QUIZ
// ============================================================

let currentQuizId = null;


async function loadQuiz() {
  const q = await agent('question');
  tagRole(q.role);

  currentQuizId = q.id;

  const quizQuestion =
    document.getElementById('quizQuestion');

  const quizResult =
    document.getElementById('quizResult');

  const quizOptions =
    document.getElementById('quizOptions');

  if (quizQuestion) {
    quizQuestion.textContent =
      q.question || 'No question available.';
  }

  if (quizResult) {
    quizResult.textContent = '';
  }

  if (quizOptions) {
    quizOptions.innerHTML =
      (q.options || [])
        .map(
          (o, i) => `
            <button
              class="btn-ghost focus-ring"
              style="text-align:left;"
              onclick="answerQuiz(${i})"
            >
              ${o}
            </button>
          `
        )
        .join('');
  }
}


async function answerQuiz(idx) {
  const res = await agent('question', {
    question_id: currentQuizId,
    selected_index: idx
  });

  const result =
    document.getElementById('quizResult');

  if (!result) return;

  result.innerHTML = res.correct
    ? `<span style="color:var(--signal);">Correct.</span>`
    : `<span style="color:var(--danger);">Not quite — review and try the next one.</span>`;
}


// ============================================================
// MOCK INTERVIEW
// ============================================================

let currentInterviewId = null;


// Load a new interview question
async function loadInterview() {
  try {

    const q = await agent('interview');

    currentInterviewId = q.id;

    const questionElement =
      document.getElementById('interviewQuestion');

    const answerElement =
      document.getElementById('interviewAnswer');

    const feedbackElement =
      document.getElementById('interviewFeedback');

    if (questionElement) {
      questionElement.textContent =
        q.question || 'No interview question available.';
    }

    if (answerElement) {
      answerElement.value = '';
    }

    if (feedbackElement) {
      feedbackElement.textContent = '';
    }

  } catch (error) {

    const questionElement =
      document.getElementById('interviewQuestion');

    const feedbackElement =
      document.getElementById('interviewFeedback');

    if (questionElement) {
      questionElement.textContent =
        'Could not load interview question.';
    }

    if (feedbackElement) {
      feedbackElement.textContent =
        error.message ||
        'Failed to load interview question.';
    }
  }
}


// Submit answer for AI evaluation
async function submitInterview() {

  const answerElement =
    document.getElementById('interviewAnswer');

  const feedbackElement =
    document.getElementById('interviewFeedback');

  const questionElement =
    document.getElementById('interviewQuestion');

  if (!answerElement || !feedbackElement || !questionElement) {
    return;
  }

  const answer =
    answerElement.value.trim();

  if (!answer) {

    feedbackElement.textContent =
      'Please write your answer first.';

    return;
  }

  const question =
    questionElement.textContent.trim();

  if (!currentInterviewId) {

    feedbackElement.textContent =
      'Interview question is not loaded yet.';

    return;
  }

  try {

    // Show loading message
    feedbackElement.innerHTML = `
      <div style="
        padding:12px;
        border-radius:10px;
        background:var(--panel);
        color:var(--mist);
      ">
        🤖 AI is evaluating your answer...
      </div>
    `;

    const res = await agent('interview', {

      question_id: currentInterviewId,

      question: question,

      answer: answer

    });


    const feedback =
      res.interview_feedback ||
      res.feedback ||
      'No feedback returned.';


    // Strengths
    const strengthsHTML =
      Array.isArray(res.strengths) &&
      res.strengths.length
        ? `
          <div style="margin-top:12px;">

            <strong>Strengths:</strong>

            <ul>
              ${res.strengths
                .map(
                  s => `<li>${s}</li>`
                )
                .join('')}
            </ul>

          </div>
        `
        : '';


    // Improvements
    const improvementsHTML =
      Array.isArray(res.improvements) &&
      res.improvements.length
        ? `
          <div style="margin-top:12px;">

            <strong>Improvements:</strong>

            <ul>
              ${res.improvements
                .map(
                  s => `<li>${s}</li>`
                )
                .join('')}
            </ul>

          </div>
        `
        : '';


    // Detailed scores
    const scoresHTML = `
      <div
        style="
          display:grid;
          grid-template-columns:repeat(2,1fr);
          gap:8px;
          margin-top:14px;
        "
      >

        ${
          res.technical_accuracy !== undefined
            ? `
              <div>
                <strong>Technical:</strong>
                ${res.technical_accuracy}/10
              </div>
            `
            : ''
        }

        ${
          res.relevance !== undefined
            ? `
              <div>
                <strong>Relevance:</strong>
                ${res.relevance}/10
              </div>
            `
            : ''
        }

        ${
          res.communication !== undefined
            ? `
              <div>
                <strong>Communication:</strong>
                ${res.communication}/10
              </div>
            `
            : ''
        }

        ${
          res.structure !== undefined
            ? `
              <div>
                <strong>Structure:</strong>
                ${res.structure}/10
              </div>
            `
            : ''
        }

      </div>
    `;


    feedbackElement.innerHTML = `
      <div
        style="
          padding:16px;
          border-radius:12px;
          background:var(--panel);
          border:1px solid var(--panelBorder);
        "
      >

        <div style="margin-bottom:10px;">

          <strong
            style="
              color:var(--ember);
              font-size:18px;
            "
          >
            Rating: ${res.rating}/5
          </strong>

        </div>


        <div
          style="
            line-height:1.6;
            color:inherit;
          "
        >
          ${feedback}
        </div>


        ${scoresHTML}


        ${strengthsHTML}


        ${improvementsHTML}


        <div
          style="
            margin-top:14px;
            font-size:11px;
            color:var(--mist);
          "
        >
          Evaluated by Groq AI
        </div>

      </div>
    `;


  } catch (error) {

    feedbackElement.innerHTML = `
      <div
        style="
          padding:12px;
          border-radius:10px;
          color:var(--danger);
          background:rgba(200,0,0,0.05);
        "
      >
        ${error.message || 'Interview evaluation failed.'}
      </div>
    `;

  }
}


// ============================================================
// PROGRESS
// ============================================================

async function loadProgress() {

  const d = await agent('progress');

  const streakNum =
    document.getElementById('streakNum');

  const quizBars =
    document.getElementById('quizBars');

  const interviewBars =
    document.getElementById('interviewBars');


  if (streakNum) {
    streakNum.textContent =
      d.streak_days;
  }


  const bar = (v, max, color) => `
    <div
      style="
        width:14px;
        height:${Math.max(
          10,
          Math.round((v / max) * 60)
        )}px;
        background:${color};
        border-radius:4px 4px 0 0;
      "
    ></div>
  `;


  if (quizBars) {

    const scores =
      d.quiz_scores && d.quiz_scores.length
        ? d.quiz_scores
        : [0, 0, 0];

    quizBars.innerHTML =
      scores
        .map(
          v => bar(
            v || 0.3,
            1,
            'var(--signal)'
          )
        )
        .join('');
  }


  if (interviewBars) {

    const scores =
      d.interview_scores &&
      d.interview_scores.length
        ? d.interview_scores
        : [1, 1, 1];

    interviewBars.innerHTML =
      scores
        .map(
          v => bar(
            v,
            5,
            'var(--ember)'
          )
        )
        .join('');
  }
}


// ============================================================
// SETTINGS
// ============================================================

async function loadSettings() {

  const d = await api('/api/settings');

  const email =
    document.getElementById('settingsEmail');

  const track =
    document.getElementById('settingsTrack');


  if (email) {
    email.textContent = d.email;
  }


  if (track) {

    track.innerHTML =
      (d.available_tracks || [])
        .map(
          t => `
            <option
              value="${t.value}"
              ${t.value === d.track ? 'selected' : ''}
            >
              ${t.label}
            </option>
          `
        )
        .join('');
  }
}


// Update career track
async function updateTrack(track) {

  await api(
    '/api/settings/track',
    {
      method: 'POST',
      body: JSON.stringify({
        track: track
      })
    }
  );

  // Track affects:
  // career
  // skill gap
  // courses
  // projects
  // quiz
  // interview
  // roadmap

}
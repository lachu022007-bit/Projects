import os
from dotenv import load_dotenv
from groq import Groq

# Load variables from backend/.env
load_dotenv()

GROQ_API_KEY = os.getenv("GROQ_API_KEY")

if not GROQ_API_KEY:
    raise RuntimeError("GROQ_API_KEY is missing from backend/.env")

client = Groq(api_key=GROQ_API_KEY)

# You can change this later if needed
MODEL = "openai/gpt-oss-20b"


def ask_groq(
    system_prompt: str,
    user_prompt: str,
    temperature: float = 0.3,
    max_tokens: int = 1000,
) -> str:

    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {
                "role": "system",
                "content": system_prompt,
            },
            {
                "role": "user",
                "content": user_prompt,
            },
        ],
        temperature=temperature,
        max_completion_tokens=max_tokens,
    )

    return response.choices[0].message.content or ""
"""
Agent orchestration layer.

Coordinator agent
    -> routes requests to the right specialist agent

Specialist agents
    -> Profile
    -> Skill Gap
    -> Roadmap
    -> Question / Quiz
    -> Interview
    -> Progress
    -> Resume

Feedback agent
    -> receives every successful specialist result
    -> generates personalized coaching feedback using Groq
"""

from __future__ import annotations

import json
import random
import re
import time

from groq_client import ask_groq

# main.py defines these objects before importing agents.py
from main import (
    db,
    get_user_track,
    TRACK_DATA,
    compute_skill_gap,
    ensure_roadmap_seeded,
    find_role,
    compute_ats_score,
    get_user_role,
    role_content,
)


# ============================================================
# FEEDBACK AGENT
# ============================================================

class FeedbackAgent:
    """
    Reviews the result produced by a specialist agent
    and adds personalized coaching feedback.
    """

    name = "feedback"

    def review(
        self,
        agent_name: str,
        uid: int,
        result: dict
    ) -> dict:

        # Do not send errors to Groq
        if "error" in result:
            return result

        try:
            note = self._groq_feedback(
                agent_name,
                result
            )

            if note:
                result["feedback"] = note
                result["feedback_source"] = "groq"
            else:
                result["feedback"] = self._fallback_feedback(
                    agent_name,
                    result
                )
                result["feedback_source"] = "fallback"

        except Exception as e:

            result["feedback"] = self._fallback_feedback(
                agent_name,
                result
            )

            result["feedback_source"] = "fallback"

            result["feedback_error"] = str(e)

        result["reviewed_by"] = self.name

        return result


    # --------------------------------------------------------
    # Groq feedback
    # --------------------------------------------------------

    def _groq_feedback(
        self,
        agent_name: str,
        result: dict
    ) -> str:

        system_prompt = """
You are the Feedback Agent inside an AI Career Mentor application.

Your job is to give useful and personalized coaching feedback
to a student based on the result of another specialist agent.

Rules:
- Use only the supplied information.
- Do not invent skills, scores, achievements, or experience.
- Be encouraging but realistic.
- Give 2 to 4 concise sentences.
- Identify the most useful next action.
- Do not use markdown tables.
"""

        user_prompt = f"""
Specialist Agent:
{agent_name}

Agent Result:
{json.dumps(result, ensure_ascii=False, default=str)}

Generate personalized coaching feedback.
"""

        return ask_groq(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            temperature=0.2,
            max_tokens=300,
        )


    # --------------------------------------------------------
    # Fallback feedback
    # --------------------------------------------------------

    def _fallback_feedback(
        self,
        agent_name: str,
        result: dict
    ) -> str:

        if agent_name == "profile":

            if result.get("status") == "saved":
                return (
                    "Profile saved successfully. "
                    "The skill gap analysis can use this information next."
                )

            return ""


        if agent_name == "skillgap":

            missing = result.get("missing_skills") or []

            if missing:

                top = missing[0]

                if isinstance(top, dict):
                    top_name = top.get("name", "the top missing skill")
                else:
                    top_name = str(top)

                return (
                    f"Focus on {top_name} next because it is an "
                    f"important gap for your selected career track."
                )

            return (
                "No major skill gaps were detected "
                "for your current track."
            )


        if agent_name == "roadmap":

            all_tasks = [
                task
                for tasks in (result.get("weeks") or {}).values()
                for task in tasks
            ]

            total = len(all_tasks) or 1

            done = sum(
                1
                for task in all_tasks
                if task.get("done")
            )

            return (
                f"You're {round(100 * done / total)}% "
                f"through the roadmap. "
                f"Keep completing your tasks consistently."
            )


        if agent_name == "question" and "correct" in result:

            if result["correct"]:
                return (
                    "Nice work. Your answer is correct. "
                    "Keep practicing similar questions."
                )

            return (
                "Not quite. Review the related concept "
                "and try another question."
            )


        if agent_name == "interview" and "rating" in result:

            return result.get(
                "interview_feedback",
                "Review your answer and improve your technical explanation."
            )


        if agent_name == "progress":

            pct = result.get(
                "roadmap_completion",
                0
            )

            if pct >= 75:
                return (
                    "Strong progress. "
                    "Keep maintaining your learning consistency."
                )

            if pct >= 40:
                return (
                    "Steady progress. "
                    "Continue completing the roadmap step by step."
                )

            return (
                "Your progress is still at an early stage. "
                "Try completing one roadmap task today."
            )


        return ""


feedback_agent = FeedbackAgent()


# ============================================================
# PROFILE AGENT
# ============================================================

class ProfileAgent:

    name = "profile"

    def handle(
        self,
        uid: int,
        payload: dict
    ) -> dict:

        education_summary = (
            payload.get("education_summary")
            or "; ".join(
                filter(
                    None,
                    [
                        payload.get("highest_qualification"),
                        payload.get("degree_branch"),
                        payload.get("institution"),
                        payload.get("graduation_year"),
                    ]
                )
            )
        )

        conn = db()

        conn.execute(
            """
            UPDATE profiles
            SET education=?,
                skills=?,
                profile_done=1
            WHERE user_id=?
            """,
            (
                education_summary,
                payload.get("current_skills", ""),
                uid
            ),
        )

        conn.commit()
        conn.close()

        return {
            "status": "saved"
        }


# ============================================================
# SKILL GAP AGENT
# ============================================================

class SkillGapAgent:
    """
    Calculates the actual skill gap using existing project logic
    and uses Groq to explain the result to the student.
    """

    name = "skillgap"

    def handle(
        self,
        uid: int,
        payload: dict
    ) -> dict:

        # Ensure roadmap exists
        ensure_roadmap_seeded(uid)

        # Student target career
        track = get_user_track(uid)

        # ----------------------------------------------------
        # Read profile and roadmap
        # ----------------------------------------------------

        conn = db()

        profile = conn.execute(
            """
            SELECT resume_skills
            FROM profiles
            WHERE user_id=?
            """,
            (uid,)
        ).fetchone()

        tasks = conn.execute(
            """
            SELECT *
            FROM roadmap_tasks
            WHERE user_id=?
            """,
            (uid,)
        ).fetchall()

        conn.close()

        # ----------------------------------------------------
        # Readiness calculation
        # ----------------------------------------------------

        total_tasks = len(tasks) or 1

        completed_tasks = sum(
            1
            for task in tasks
            if task["done"]
        )

        readiness = round(
            30 + 60 * (
                completed_tasks / total_tasks
            )
        )

        # Keep readiness between 0 and 100
        readiness = max(
            0,
            min(100, readiness)
        )

        # ----------------------------------------------------
        # Resume skills
        # ----------------------------------------------------

        resume_skills = []

        if profile and profile["resume_skills"]:

            try:

                resume_skills = json.loads(
                    profile["resume_skills"]
                )

            except (
                json.JSONDecodeError,
                TypeError
            ):

                resume_skills = []


        # ----------------------------------------------------
        # Existing deterministic skill calculation
        # ----------------------------------------------------

        strong_skills, missing_skills = compute_skill_gap(
            resume_skills,
            track,
            get_user_role(uid)
        )


        # ----------------------------------------------------
        # Convert missing skills to simple names
        # ----------------------------------------------------

        missing_names = []

        for skill in missing_skills:

            if isinstance(skill, dict):

                name = skill.get("name")

                if name:
                    missing_names.append(name)

            else:

                missing_names.append(
                    str(skill)
                )


        # ----------------------------------------------------
        # Groq explanation
        # ----------------------------------------------------

        system_prompt = """
You are the Skill Gap Agent inside an AI Career Mentor application.

Your task is to explain the student's skills and gaps
for their selected career track.

Rules:
- Use only the supplied information.
- Do not invent skills or experience.
- Do not change the calculated skill gap.
- Explain the most important missing skills.
- Explain why they matter for the target role.
- Recommend what to learn first.
- Give one practical project idea.
- Keep the response concise.
"""

        user_prompt = f"""
Target Career Track:
{track}

Student Skills:
{json.dumps(strong_skills, ensure_ascii=False)}

Missing Skills:
{json.dumps(missing_names, ensure_ascii=False)}

Current Readiness:
{readiness}%

Explain:

1. Strong relevant skills
2. Most important missing skills
3. Why those skills matter
4. What the student should learn first
5. One practical project to close the gap
"""

        try:

            ai_explanation = ask_groq(
                system_prompt=system_prompt,
                user_prompt=user_prompt,
                temperature=0.2,
                max_tokens=600,
            )

            ai_source = "groq"

        except Exception as e:

            ai_explanation = (
                "AI skill-gap explanation is temporarily unavailable. "
                "Use the detected missing skills to prioritize learning."
            )

            ai_source = "fallback"


        # ----------------------------------------------------
        # Final response
        # ----------------------------------------------------

        return {
            "track": track,
            "strong_skills": strong_skills,
            "missing_skills": missing_skills,
            "readiness": readiness,
            "ai_explanation": ai_explanation,
            "ai_source": ai_source,
        }


# ============================================================
# ROADMAP AGENT
# ============================================================

class RoadmapAgent:

    name = "roadmap"

    def handle(
        self,
        uid: int,
        payload: dict
    ) -> dict:

        ensure_roadmap_seeded(uid)

        conn = db()

        toggle_id = payload.get(
            "toggle_task_id"
        )

        # ----------------------------------------------------
        # Update task
        # ----------------------------------------------------

        if toggle_id is not None:

            row = conn.execute(
                """
                SELECT *
                FROM roadmap_tasks
                WHERE id=?
                AND user_id=?
                """,
                (
                    toggle_id,
                    uid
                )
            ).fetchone()

            if not row:

                conn.close()

                return {
                    "error": "Task not found"
                }

            conn.execute(
                """
                UPDATE roadmap_tasks
                SET done=?
                WHERE id=?
                """,
                (
                    1
                    if payload.get("done")
                    else 0,
                    toggle_id
                )
            )

            conn.commit()


        # ----------------------------------------------------
        # Fetch roadmap
        # ----------------------------------------------------

        rows = conn.execute(
            """
            SELECT *
            FROM roadmap_tasks
            WHERE user_id=?
            ORDER BY week, day
            """,
            (uid,)
        ).fetchall()

        conn.close()


        weeks: dict = {}

        for row in rows:

            weeks.setdefault(
                row["week"],
                []
            ).append(
                dict(row)
            )


        result = {
            "weeks": weeks,
            "role": role_content(uid, "roadmap_titles")[1]
        }


        if toggle_id is not None:

            result["status"] = "updated"


        return result


# ============================================================
# QUESTION / QUIZ AGENT
# ============================================================

class QuestionAgent:

    name = "question"

    def handle(
        self,
        uid: int,
        payload: dict
    ) -> dict:

        track = get_user_track(uid)

        # ----------------------------------------------------
        # Answer existing question
        # ----------------------------------------------------

        if (
            payload.get("question_id") is not None
            and "selected_index" in payload
        ):

            q = next(
                (
                    item
                    for item in role_content(uid, "quiz_bank")[0]
                    if item["id"]
                    == payload["question_id"]
                ),
                None
            )

            if not q:

                return {
                    "error": "Question not found"
                }


            correct = (
                payload["selected_index"]
                == q["answer"]
            )


            conn = db()

            conn.execute(
                """
                INSERT INTO quiz_scores
                (user_id, correct, total, created_at)
                VALUES (?, ?, ?, ?)
                """,
                (
                    uid,
                    1 if correct else 0,
                    1,
                    time.time()
                )
            )

            conn.commit()
            conn.close()


            return {
                "correct": correct,
                "correct_index": q["answer"]
            }


        # ----------------------------------------------------
        # Give a new question
        # ----------------------------------------------------

        q = random.choice(
            role_content(uid, "quiz_bank")[0]
        )

        return {
            "role": role_content(uid, "quiz_bank")[1],
            "id": q["id"],
            "question": q["q"],
            "options": q["options"]
        }


# ============================================================
# INTERVIEW AGENT
# ============================================================

class InterviewAgent:
    """
    AI-powered technical interview agent using Groq.
    """

    name = "interview"

    def handle(
        self,
        uid: int,
        payload: dict
    ) -> dict:

        track = get_user_track(uid)

        # ----------------------------------------------------
        # Student submitted an answer
        # ----------------------------------------------------

        if (
            payload.get("question_id") is not None
            and "answer" in payload
        ):

            question = (
                payload.get("question", "")
                .strip()
            )

            answer = (
                payload.get("answer", "")
                .strip()
            )


            if not answer:

                return {
                    "error":
                    "Please provide an answer before submitting."
                }


            if not question:

                return {
                    "error":
                    "Interview question is missing."
                }


            # ------------------------------------------------
            # Ask Groq to evaluate
            # ------------------------------------------------

            evaluation = self.evaluate_answer(
                track=track,
                question=question,
                answer=answer
            )


            # ------------------------------------------------
            # Rating
            # ------------------------------------------------

            rating = evaluation.get(
                "rating",
                3
            )

            try:
                rating = int(rating)
            except (
                TypeError,
                ValueError
            ):
                rating = 3

            rating = max(
                1,
                min(5, rating)
            )


            note = evaluation.get(
                "feedback",
                "Review your answer and improve your explanation."
            )


            # ------------------------------------------------
            # Save to SQLite
            # ------------------------------------------------

            conn = db()

            conn.execute(
                """
                INSERT INTO interview_scores
                (user_id, rating, feedback, created_at)
                VALUES (?, ?, ?, ?)
                """,
                (
                    uid,
                    rating,
                    note,
                    time.time()
                )
            )

            conn.commit()
            conn.close()


            # ------------------------------------------------
            # Return evaluation
            # ------------------------------------------------

            return {
                "rating": rating,

                "technical_accuracy":
                    evaluation.get(
                        "technical_accuracy",
                        0
                    ),

                "relevance":
                    evaluation.get(
                        "relevance",
                        0
                    ),

                "communication":
                    evaluation.get(
                        "communication",
                        0
                    ),

                "structure":
                    evaluation.get(
                        "structure",
                        0
                    ),

                "strengths":
                    evaluation.get(
                        "strengths",
                        []
                    ),

                "improvements":
                    evaluation.get(
                        "improvements",
                        []
                    ),

                "interview_feedback":
                    note,

                "evaluated_by":
                    "Groq"
            }


        # ----------------------------------------------------
        # Generate new question
        # ----------------------------------------------------

        q = random.choice(
            TRACK_DATA[track]["interview_bank"]
        )


        return {
            "id": q["id"],
            "question": q["q"]
        }


    # ========================================================
    # GROQ INTERVIEW EVALUATION
    # ========================================================

    def evaluate_answer(
        self,
        track: str,
        question: str,
        answer: str
    ) -> dict:

        system_prompt = """
You are an AI technical interview evaluator
inside a Career Mentor application.

Evaluate the student's answer fairly.

Evaluate:
1. Technical accuracy
2. Relevance
3. Communication
4. Structure

Return ONLY valid JSON:

{
  "rating": 1,
  "technical_accuracy": 0,
  "relevance": 0,
  "communication": 0,
  "structure": 0,
  "strengths": [],
  "improvements": [],
  "feedback": ""
}

Rules:
- rating must be an integer from 1 to 5
- category scores must be from 0 to 10
- do not invent information
- evaluate only the submitted answer
- do not reward an answer merely because it is long
- be concise and practical
"""


        user_prompt = f"""
Career Track:
{track}

Interview Question:
{question}

Student Answer:
{answer}

Evaluate this answer.
"""


        try:

            response = ask_groq(
                system_prompt=system_prompt,
                user_prompt=user_prompt,
                temperature=0.1,
                max_tokens=500,
            )


            response = response.strip()


            # ------------------------------------------------
            # Remove markdown code block
            # ------------------------------------------------

            if response.startswith("```"):

                response = response.replace(
                    "```json",
                    ""
                )

                response = response.replace(
                    "```",
                    ""
                )

                response = response.strip()


            parsed = json.loads(
                response
            )


            # ------------------------------------------------
            # Make sure fields exist
            # ------------------------------------------------

            return {
                "rating":
                    parsed.get(
                        "rating",
                        3
                    ),

                "technical_accuracy":
                    parsed.get(
                        "technical_accuracy",
                        0
                    ),

                "relevance":
                    parsed.get(
                        "relevance",
                        0
                    ),

                "communication":
                    parsed.get(
                        "communication",
                        0
                    ),

                "structure":
                    parsed.get(
                        "structure",
                        0
                    ),

                "strengths":
                    parsed.get(
                        "strengths",
                        []
                    ),

                "improvements":
                    parsed.get(
                        "improvements",
                        []
                    ),

                "feedback":
                    parsed.get(
                        "feedback",
                        ""
                    )
            }


        except Exception as e:

            return {
                "rating": 3,

                "technical_accuracy": 0,

                "relevance": 0,

                "communication": 0,

                "structure": 0,

                "strengths": [],

                "improvements": [],

                "feedback": (
                    "Your answer was received, but AI evaluation "
                    "is temporarily unavailable. Please review the "
                    "technical correctness and structure of your answer."
                ),

                "evaluation_error":
                    str(e)
            }


# ============================================================
# PROGRESS AGENT
# ============================================================

class ProgressAgent:
    """
    Reads quiz, interview and roadmap activity
    and returns progress information.
    """

    name = "progress"

    def handle(
        self,
        uid: int,
        payload: dict
    ) -> dict:

        conn = db()


        quiz = conn.execute(
            """
            SELECT correct, total, created_at
            FROM quiz_scores
            WHERE user_id=?
            ORDER BY created_at
            """,
            (uid,)
        ).fetchall()


        interviews = conn.execute(
            """
            SELECT rating, created_at
            FROM interview_scores
            WHERE user_id=?
            ORDER BY created_at
            """,
            (uid,)
        ).fetchall()


        tasks = conn.execute(
            """
            SELECT done
            FROM roadmap_tasks
            WHERE user_id=?
            """,
            (uid,)
        ).fetchall()


        conn.close()


        total = len(tasks) or 1

        done = sum(
            1
            for task in tasks
            if task["done"]
        )


        streak = min(
            30,
            done
        )


        return {
            "streak_days": streak,

            "quiz_scores": [
                row["correct"]
                for row in quiz
            ][-8:],

            "interview_scores": [
                row["rating"]
                for row in interviews
            ][-8:],

            "roadmap_completion":
                round(
                    100 * done / total
                )
        }


# ============================================================
# RESUME AGENT
# ============================================================
class ResumeAgent:
    """
    Analyzes the student's already-uploaded resume.

    Unlike the earlier version, this reads the actual extracted resume text
    (profiles.resume_text) for the authenticated uid, so the Groq analysis is
    grounded in the real document rather than a bare list of detected skills.
    """

    name = "resume"

    MAX_RESUME_CHARS = 9000

    def handle(self, uid: int, payload: dict) -> dict:

        conn = db()

        profile = conn.execute(
            """
            SELECT resume_skills, resume_score, resume_done,
                   resume_text, resume_filename, target_job
            FROM profiles
            WHERE user_id=?
            """,
            (uid,)
        ).fetchone()

        conn.close()

        if not profile:
            return {"error": "Profile not found"}

        if not profile["resume_done"]:
            return {"error": "Please upload your resume first."}

        # ------------------------------------------------
        # Stored resume information (this user's only)
        # ------------------------------------------------

        try:
            resume_skills = (
                json.loads(profile["resume_skills"])
                if profile["resume_skills"]
                else []
            )
        except Exception:
            resume_skills = []

        resume_score = profile["resume_score"] or 0
        resume_text = (profile["resume_text"] or "").strip()
        track = get_user_track(uid)
        target_job_raw = (profile["target_job"] or "").strip()
        role = find_role(target_job_raw) if target_job_raw else None
        target_job = role["role"] if role else (
            target_job_raw or TRACK_DATA.get(track, {}).get("label", track)
        )
        ats = compute_ats_score(resume_skills, role) if role else None

        base_result = {
            "track": track,
            "target_job": target_job,
            "resume_score": resume_score,
            "ats_score": ats["score"] if ats else None,
            "ats_matched_keywords": ats["matched_keywords"] if ats else [],
            "ats_missing_keywords": ats["missing_keywords"] if ats else [],
            "resume_skills": resume_skills,
            "resume_filename": profile["resume_filename"],
        }

        if not resume_text:
            if not resume_skills and not resume_score:
                # Never actually analyzed (e.g. an old "skipped" row).
                return {"error": "Please upload your resume first."}
            # Parsed before resume_text was stored (older upload). Still return
            # real stored values rather than inventing an analysis.
            return {
                **base_result,
                "analysis": (
                    "Resume score and detected skills are available, but the stored "
                    "resume text is missing. Please re-upload your resume to get the "
                    "full AI analysis."
                ),
                "analysis_source": "fallback",
            }

        # ------------------------------------------------
        # Groq analysis, grounded in the real resume text
        # ------------------------------------------------

        system_prompt = """
You are the Resume Analysis Agent in an AI Career Mentor for students.

You will be given the actual text extracted from one student's resume and
their target career.

Strict rules:
- Use ONLY the supplied resume text and target career.
- Never invent internships, projects, skills, education, achievements,
  employers, dates or experience that are not present in the text.
- If something is missing from the resume, say it is missing — do not imagine it.
- The resume quality score you are given is an application-generated
  heuristic, not a professionally validated assessment. Do not describe it as
  validated. The ATS score (when given) is a separate keyword-match score
  against the target job role's required skills — treat them as different
  numbers with different meanings, and don't conflate them.
- Be specific and practical. Quote or reference real lines from the resume
  when pointing at something.

Respond with EXACTLY these seven sections, in this order, each on its own
line as a heading followed by short bullet points:

Strengths
Improvements
Missing Skills
ATS / Content Improvements
Project Improvements
Career Alignment
Next Action

"Next Action" must be exactly one concrete action.
Do not add any other sections, preamble or closing remarks.
"""

        ats_block = ""
        if ats:
            ats_block = f"""
ATS keyword match score for this specific role: {ats['score']}/100
Required keywords already found in the resume: {json.dumps(ats['matched_keywords'], ensure_ascii=False)}
Required keywords NOT found in the resume: {json.dumps(ats['missing_keywords'], ensure_ascii=False)}
"""

        user_prompt = f"""
Target job role:
{target_job} (track: {track})
{ats_block}
Application-generated resume quality score (structure/completeness, not keyword-based):
{resume_score}/100

All skills automatically detected in the resume text:
{json.dumps(resume_skills, ensure_ascii=False)}

--- BEGIN RESUME TEXT ---
{resume_text[: self.MAX_RESUME_CHARS]}
--- END RESUME TEXT ---

Analyze this resume for the target job role above, following the seven required
sections. When an ATS score and required-keyword lists are given above, ground
"Missing Skills" and "ATS / Content Improvements" in those exact keywords
rather than guessing. Base every statement on the resume text above.
"""

        try:
            analysis = ask_groq(
                system_prompt=system_prompt,
                user_prompt=user_prompt,
                temperature=0.2,
                max_tokens=1100,
            )
            source = "groq"

        except Exception as e:
            # Groq being down must never break the upload: the parsed score and
            # detected skills are real and are still returned.
            print(f"[ResumeAgent] Groq call failed for uid={uid}: {e}")
            analysis = (
                "Resume uploaded and parsed successfully. "
                "AI analysis is temporarily unavailable."
            )
            source = "fallback"

        return {
            **base_result,
            "analysis": analysis,
            "analysis_source": source,
            "sections": self._split_sections(analysis) if source == "groq" else {},
        }

    # --------------------------------------------------------
    # Splits the model's response into the seven known sections
    # so the frontend can render them as separate blocks.
    # Falls back to an empty dict if the shape is unexpected.
    # --------------------------------------------------------

    SECTION_KEYS = [
        ("strengths", "Strengths"),
        ("improvements", "Improvements"),
        ("missing_skills", "Missing Skills"),
        ("ats", "ATS / Content Improvements"),
        ("projects", "Project Improvements"),
        ("alignment", "Career Alignment"),
        ("next_action", "Next Action"),
    ]

    def _split_sections(self, analysis: str) -> dict:
        if not analysis:
            return {}

        headings = [label for _, label in self.SECTION_KEYS]
        pattern = "|".join(re.escape(h) for h in headings)
        # Match a heading on its own line, optionally decorated with #, *, digits.
        regex = re.compile(
            r"^[#*\d.\-\s]*(" + pattern + r")[#*:\s]*$",
            re.IGNORECASE | re.MULTILINE,
        )

        matches = list(regex.finditer(analysis))
        if not matches:
            return {}

        label_to_key = {label.lower(): key for key, label in self.SECTION_KEYS}
        out = {}
        for i, m in enumerate(matches):
            key = label_to_key.get(m.group(1).lower())
            if not key:
                continue
            end = matches[i + 1].start() if i + 1 < len(matches) else len(analysis)
            body = analysis[m.end():end].strip()
            if body:
                out[key] = body
        return out


# ============================================================
# COORDINATOR AGENT
# ============================================================

class CoordinatorAgent:
    """
    Central router.

    It:
    1. Receives the requested agent name
    2. Finds the specialist agent
    3. Runs the specialist
    4. Sends the result through FeedbackAgent
    """

    def __init__(self):

        self._agents = {

            "profile":
                ProfileAgent(),

            "resume":
                ResumeAgent(),

            "skillgap":
                SkillGapAgent(),

            "roadmap":
                RoadmapAgent(),

            "question":
                QuestionAgent(),

            "interview":
                InterviewAgent(),

            "progress":
                ProgressAgent(),
        }


    def dispatch(
        self,
        agent_name: str,
        uid: int,
        payload: dict
    ) -> dict:

        agent = self._agents.get(
            agent_name
        )


        if agent is None:

            return {
                "error":
                    f"Unknown agent '{agent_name}'",

                "available":
                    sorted(
                        self._agents.keys()
                    )
            }


        try:

            result = agent.handle(
                uid,
                payload or {}
            )

        except Exception as e:

            return {
                "error":
                    f"{agent_name} agent failed: {str(e)}"
            }


        return feedback_agent.review(
            agent_name,
            uid,
            result
        )


# ============================================================
# GLOBAL COORDINATOR INSTANCE
# ============================================================

coordinator = CoordinatorAgent()

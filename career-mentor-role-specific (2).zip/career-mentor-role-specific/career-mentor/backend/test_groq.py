from groq_client import ask_groq

answer = ask_groq(
    system_prompt="You are a helpful career mentor.",
    user_prompt="Give me one practical tip for becoming an ML Engineer."
)

print(answer)
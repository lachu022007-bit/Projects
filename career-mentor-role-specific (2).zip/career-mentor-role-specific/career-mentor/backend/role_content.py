"""
Role-specific learning content.

Courses, projects, quiz questions and roadmap titles used to be keyed only by
*track* (tech / design / marketing), so every role inside a track saw the same
thing. This module keys them by the exact role name that the role picker
stores in profiles.target_job, so each role gets its own material.

Keys MUST match the "role" names in TRACK_DATA[...]["recommendations"].
"""


def _yt(q):
    return "https://www.youtube.com/results?search_query=" + q.replace(" ", "+")


def _gh(q):
    return "https://github.com/search?q=" + q.replace(" ", "+")


def _cs(q):
    return "https://www.coursera.org/search?query=" + q.replace(" ", "%20")


ROLE_CONTENT = {
    # ------------------------------------------------------------------ TECH
    "AI/ML Engineer": {
        "growth_skills": ["MLOps", "Docker", "Model deployment", "Deep learning"],
        "courses": [
            {"title": "Machine Learning Specialization", "platform": "Coursera", "duration": "3 months", "free": False, "url": _cs("machine learning specialization")},
            {"title": "Deep Learning with PyTorch", "platform": "YouTube", "duration": "8h 00m", "free": True, "url": _yt("deep learning pytorch full course")},
            {"title": "MLOps: Deploying Models with Docker & FastAPI", "platform": "YouTube", "duration": "3h 30m", "free": True, "url": _yt("mlops docker fastapi model deployment")},
        ],
        "projects": [
            {"title": "Containerized ML API", "level": "Intermediate", "outcome": "Ship a real model behind a real container boundary.", "url": _gh("containerized ml api fastapi docker")},
            {"title": "Image classifier with transfer learning", "level": "Beginner", "outcome": "Fine-tune a pretrained CNN and report accuracy honestly.", "url": _gh("transfer learning image classifier pytorch")},
            {"title": "RAG chatbot over your own documents", "level": "Advanced", "outcome": "Combine embeddings, a vector store and an LLM into one working app.", "url": _gh("rag chatbot faiss langchain")},
        ],
        "roadmap_titles": ["Python & NumPy/Pandas refresh", "Supervised learning fundamentals", "Model evaluation & metrics",
                           "Neural networks with PyTorch", "Serve a model with FastAPI", "Docker & MLOps basics",
                           "Build an end-to-end ML project", "ML mock interview", "Review & consolidate"],
        "quiz_bank": [
            {"id": 1, "q": "Which technique helps reduce overfitting in a neural network?", "options": ["Dropout", "Adding more layers", "Removing the validation set"], "answer": 0},
            {"id": 2, "q": "Which metric is most informative for a heavily imbalanced classification problem?", "options": ["Accuracy", "F1 score", "Mean squared error"], "answer": 1},
            {"id": 3, "q": "What does the learning rate control in gradient descent?", "options": ["The size of each weight update", "The number of layers", "The batch count"], "answer": 0},
            {"id": 4, "q": "Why do we split data into train and test sets?", "options": ["To make training faster", "To estimate performance on unseen data", "To increase the dataset size"], "answer": 1},
            {"id": 5, "q": "Which Docker command builds an image from a Dockerfile?", "options": ["docker run", "docker build", "docker exec"], "answer": 1},
        ],
    },
    "Full-stack Developer": {
        "growth_skills": ["TypeScript", "REST API design", "Authentication", "Testing"],
        "courses": [
            {"title": "The Complete React Course", "platform": "YouTube", "duration": "10h 00m", "free": True, "url": _yt("react full course")},
            {"title": "Django for Professionals", "platform": "Docs", "duration": "6h 00m", "free": True, "url": "https://docs.djangoproject.com/en/stable/intro/tutorial01/"},
            {"title": "Web Authentication & Security Basics", "platform": "Coursera", "duration": "4 weeks", "free": False, "url": _cs("web application security")},
        ],
        "projects": [
            {"title": "Personal task tracker", "level": "Beginner", "outcome": "Learn CRUD end to end, from React form to database row.", "url": _gh("task tracker crud react django")},
            {"title": "Blog platform with login", "level": "Intermediate", "outcome": "Build auth, roles and a REST API behind a React frontend.", "url": _gh("blog platform react django jwt")},
            {"title": "Real-time chat app", "level": "Advanced", "outcome": "Handle WebSockets, state sync and deployment.", "url": _gh("realtime chat app websockets react")},
        ],
        "roadmap_titles": ["JavaScript & TypeScript refresh", "React components & state", "Routing and forms",
                           "Build a REST API with Django", "Authentication & sessions", "Connect frontend to backend",
                           "Deploy a full-stack app", "Full-stack mock interview", "Review & consolidate"],
        "quiz_bank": [
            {"id": 1, "q": "In React, which hook stores local component state?", "options": ["useEffect", "useState", "useRef"], "answer": 1},
            {"id": 2, "q": "Which HTTP status code means a resource was created?", "options": ["200", "201", "204"], "answer": 1},
            {"id": 3, "q": "What does CORS control?", "options": ["Which origins may call your API from a browser", "Database indexing", "Password hashing"], "answer": 0},
            {"id": 4, "q": "In Django, what defines the database schema?", "options": ["Views", "Models", "Templates"], "answer": 1},
            {"id": 5, "q": "Why should passwords be hashed rather than encrypted?", "options": ["Hashing is one-way, so they cannot be recovered", "Hashing is reversible", "Hashing is faster to read back"], "answer": 0},
        ],
    },
    "Backend Developer": {
        "growth_skills": ["Docker", "Caching (Redis)", "Message queues", "Database indexing"],
        "courses": [
            {"title": "System Design Primer", "platform": "Coursera", "duration": "6 weeks", "free": False, "url": _cs("system design")},
            {"title": "SQL Performance Tuning", "platform": "Docs", "duration": "2h 10m", "free": True, "url": "https://use-the-index-luke.com/"},
            {"title": "FastAPI Full Course", "platform": "YouTube", "duration": "5h 00m", "free": True, "url": _yt("fastapi full course")},
        ],
        "projects": [
            {"title": "URL shortener service", "level": "Beginner", "outcome": "Design an API, a schema and a redirect flow.", "url": _gh("url shortener fastapi")},
            {"title": "Rate-limited public API", "level": "Intermediate", "outcome": "Add auth, rate limiting and caching with Redis.", "url": _gh("rate limiter redis fastapi")},
            {"title": "Distributed job queue", "level": "Advanced", "outcome": "Understand what scale actually means.", "url": _gh("distributed job queue python")},
        ],
        "roadmap_titles": ["Data structures & HTTP refresh", "Design REST APIs properly", "SQL joins & schema design",
                           "Indexing & query tuning", "Caching with Redis", "Background jobs & queues",
                           "System design case study", "Backend mock interview", "Review & consolidate"],
        "quiz_bank": [
            {"id": 1, "q": "Which HTTP method is idempotent by convention?", "options": ["POST", "PUT", "None of them"], "answer": 1},
            {"id": 2, "q": "What is the main purpose of a database index?", "options": ["Speed up reads on a column", "Encrypt the column", "Reduce table columns"], "answer": 0},
            {"id": 3, "q": "Which SQL clause filters rows before aggregation?", "options": ["HAVING", "WHERE", "ORDER BY"], "answer": 1},
            {"id": 4, "q": "What does a cache mainly help with?", "options": ["Lower latency for repeated reads", "Stronger passwords", "Smaller Docker images"], "answer": 0},
            {"id": 5, "q": "What is horizontal scaling?", "options": ["Adding more machines", "Adding more RAM to one machine", "Rewriting in another language"], "answer": 0},
        ],
    },
    "Data Analyst": {
        "growth_skills": ["Power BI / Tableau", "Statistics", "Data cleaning", "Excel"],
        "courses": [
            {"title": "SQL for Data Analysis", "platform": "YouTube", "duration": "4h 00m", "free": True, "url": _yt("sql for data analysis full course")},
            {"title": "Data Analysis with Pandas", "platform": "YouTube", "duration": "6h 00m", "free": True, "url": _yt("pandas data analysis full course")},
            {"title": "Data Visualization with Tableau", "platform": "Coursera", "duration": "5 weeks", "free": False, "url": _cs("tableau data visualization")},
        ],
        "projects": [
            {"title": "Sales dashboard", "level": "Beginner", "outcome": "Turn a raw CSV into a dashboard a manager could use.", "url": _gh("sales dashboard power bi tableau")},
            {"title": "Customer churn analysis", "level": "Intermediate", "outcome": "Clean data, find drivers and present recommendations.", "url": _gh("customer churn analysis pandas")},
            {"title": "A/B test analysis report", "level": "Advanced", "outcome": "Apply hypothesis testing and explain results to non-experts.", "url": _gh("ab test analysis python")},
        ],
        "roadmap_titles": ["Excel & spreadsheet refresh", "SQL joins and aggregation", "Clean data with Pandas",
                           "Exploratory data analysis", "Statistics for analysts", "Build a BI dashboard",
                           "Present insights as a story", "Analyst mock interview", "Review & consolidate"],
        "quiz_bank": [
            {"id": 1, "q": "Which SQL clause groups rows for aggregation?", "options": ["GROUP BY", "ORDER BY", "LIMIT"], "answer": 0},
            {"id": 2, "q": "Which Pandas method shows summary statistics of numeric columns?", "options": ["df.head()", "df.describe()", "df.shape"], "answer": 1},
            {"id": 3, "q": "What does a p-value below 0.05 usually suggest?", "options": ["The result is unlikely under the null hypothesis", "The data is clean", "The sample is large"], "answer": 0},
            {"id": 4, "q": "Which chart best shows a trend over time?", "options": ["Line chart", "Pie chart", "Scatter of categories"], "answer": 0},
            {"id": 5, "q": "What is the median?", "options": ["The average value", "The middle value when sorted", "The most frequent value"], "answer": 1},
        ],
    },
    # ---------------------------------------------------------------- DESIGN
    "Product Designer": {
        "growth_skills": ["Design systems", "Accessibility (WCAG)", "Product strategy", "Prototyping"],
        "courses": [
            {"title": "Design Systems 101", "platform": "YouTube", "duration": "3h 40m", "free": True, "url": _yt("design systems 101")},
            {"title": "Google UX Design Certificate", "platform": "Coursera", "duration": "6 months", "free": False, "url": _cs("google ux design")},
            {"title": "Accessibility for Designers", "platform": "Coursera", "duration": "4 weeks", "free": False, "url": _cs("accessibility design")},
        ],
        "projects": [
            {"title": "Component library", "level": "Beginner", "outcome": "Learn design tokens and reusable components.", "url": "https://www.figma.com/community/search?resource_type=components&query=component%20library"},
            {"title": "Redesign a checkout flow", "level": "Intermediate", "outcome": "Ship a case study with before/after metrics.", "url": "https://www.behance.net/search/projects?search=checkout+flow+redesign"},
            {"title": "End-to-end product design sprint", "level": "Advanced", "outcome": "Practice research through hi-fi prototype in one week.", "url": "https://www.behance.net/search/projects?search=design+sprint+case+study"},
        ],
        "roadmap_titles": ["Design fundamentals refresh", "User flows & wireframes", "Build a design system",
                           "Accessibility (WCAG) audit", "Hi-fi prototype in Figma", "Write a product case study",
                           "Portfolio review", "Design mock interview", "Review & consolidate"],
        "quiz_bank": [
            {"id": 1, "q": "In Figma, what lets you build reusable UI elements?", "options": ["Frames", "Components", "Comments"], "answer": 1},
            {"id": 2, "q": "What are design tokens?", "options": ["Named values for colour, spacing and type", "Login credentials", "Prototype animations"], "answer": 0},
            {"id": 3, "q": "What does WCAG primarily set standards for?", "options": ["Web accessibility", "Web speed", "Web hosting"], "answer": 0},
            {"id": 4, "q": "What is the main goal of a product design sprint?", "options": ["Test an idea quickly before building it", "Ship final code", "Rebrand the company"], "answer": 0},
            {"id": 5, "q": "Which is a key part of a strong case study?", "options": ["The problem, process and measurable outcome", "Only final screens", "A list of tools used"], "answer": 0},
        ],
    },
    "UX Researcher": {
        "growth_skills": ["Usability testing", "Survey design", "Research synthesis", "Interviewing"],
        "courses": [
            {"title": "User Research Fundamentals", "platform": "YouTube", "duration": "3h 00m", "free": True, "url": _yt("user research fundamentals ux")},
            {"title": "Conducting User Interviews", "platform": "Docs", "duration": "1h 30m", "free": True, "url": "https://www.nngroup.com/articles/user-interviews/"},
            {"title": "UX Research & Design Strategy", "platform": "Coursera", "duration": "4 weeks", "free": False, "url": _cs("ux research")},
        ],
        "projects": [
            {"title": "Competitor usability review", "level": "Beginner", "outcome": "Run a heuristic evaluation and rank the top issues.", "url": "https://www.nngroup.com/articles/ten-usability-heuristics/"},
            {"title": "Interview study with 5 users", "level": "Intermediate", "outcome": "Plan, run and synthesize interviews into themes.", "url": "https://www.behance.net/search/projects?search=ux+research+case+study"},
            {"title": "Mixed-methods research report", "level": "Advanced", "outcome": "Combine survey data with interviews to make a recommendation.", "url": "https://www.behance.net/search/projects?search=ux+research+report"},
        ],
        "roadmap_titles": ["Research fundamentals refresh", "Write a research plan", "Recruit & screen participants",
                           "Run user interviews", "Usability testing sessions", "Affinity mapping & synthesis",
                           "Report findings to stakeholders", "Research mock interview", "Review & consolidate"],
        "quiz_bank": [
            {"id": 1, "q": "How many users typically uncover most usability problems in one round of testing?", "options": ["About 5", "About 500", "Exactly 1"], "answer": 0},
            {"id": 2, "q": "Which is a leading interview question to avoid?", "options": ["Don't you think this button is confusing?", "How did you complete this task?", "What did you expect to happen?"], "answer": 0},
            {"id": 3, "q": "What is affinity mapping used for?", "options": ["Grouping observations into themes", "Designing icons", "Measuring page speed"], "answer": 0},
            {"id": 4, "q": "Qualitative research mainly answers which question?", "options": ["Why do users behave this way?", "How many users clicked?", "What is the conversion rate?"], "answer": 0},
            {"id": 5, "q": "What is a screener survey for?", "options": ["Selecting the right participants", "Testing colours", "Tracking revenue"], "answer": 0},
        ],
    },
    "UI Designer": {
        "growth_skills": ["Typography", "Colour theory", "Motion design", "Design systems"],
        "courses": [
            {"title": "Visual Design Principles", "platform": "YouTube", "duration": "3h 20m", "free": True, "url": _yt("ui visual design principles typography color")},
            {"title": "Motion Design Basics", "platform": "Docs", "duration": "2h 00m", "free": True, "url": "https://www.smashingmagazine.com/category/motion-design/"},
            {"title": "UI Design Specialization", "platform": "Coursera", "duration": "4 months", "free": False, "url": _cs("ui design")},
        ],
        "projects": [
            {"title": "Landing page redesign", "level": "Beginner", "outcome": "Practise hierarchy, spacing and type on a real page.", "url": "https://www.behance.net/search/projects?search=landing+page+redesign"},
            {"title": "Mobile app UI kit", "level": "Intermediate", "outcome": "Design a consistent set of screens with reusable components.", "url": "https://www.figma.com/community/search?resource_type=files&query=mobile%20ui%20kit"},
            {"title": "Animated micro-interactions set", "level": "Advanced", "outcome": "Add motion that guides users without distracting them.", "url": "https://www.behance.net/search/projects?search=micro+interactions"},
        ],
        "roadmap_titles": ["Visual design fundamentals", "Typography & hierarchy", "Colour palettes & contrast",
                           "Layout grids & spacing", "Build a UI kit in Figma", "Micro-interactions & motion",
                           "Polish a portfolio piece", "UI mock interview", "Review & consolidate"],
        "quiz_bank": [
            {"id": 1, "q": "What does visual hierarchy help users do?", "options": ["See what matters first", "Load pages faster", "Log in securely"], "answer": 0},
            {"id": 2, "q": "In Figma, which feature makes elements resize responsively?", "options": ["Auto layout", "Comments", "Version history"], "answer": 0},
            {"id": 3, "q": "Which contrast ratio does WCAG AA require for normal body text?", "options": ["4.5:1", "1.5:1", "10:1"], "answer": 0},
            {"id": 4, "q": "What is an 8-point grid used for?", "options": ["Consistent spacing and sizing", "Choosing fonts", "Animating icons"], "answer": 0},
            {"id": 5, "q": "Which is the best use of motion in UI?", "options": ["Give feedback and guide attention", "Decorate every element", "Slow the interface down"], "answer": 0},
        ],
    },
    # ------------------------------------------------------------- MARKETING
    "Growth Marketer": {
        "growth_skills": ["A/B testing", "Paid media (PPC)", "Funnel analytics", "Marketing automation"],
        "courses": [
            {"title": "A/B Testing for Marketers", "platform": "Docs", "duration": "1h 50m", "free": True, "url": "https://cxl.com/blog/ab-testing-guide/"},
            {"title": "PPC Fundamentals", "platform": "YouTube", "duration": "3h 10m", "free": True, "url": _yt("ppc fundamentals google ads")},
            {"title": "Growth Marketing Minidegree", "platform": "Coursera", "duration": "5 weeks", "free": False, "url": _cs("growth marketing")},
        ],
        "projects": [
            {"title": "Landing page conversion audit", "level": "Beginner", "outcome": "Find and rank the biggest conversion leaks.", "url": "https://cxl.com/blog/ab-testing-guide/"},
            {"title": "Run a small PPC campaign", "level": "Intermediate", "outcome": "Ship a campaign with real budget and CTR/CPA metrics.", "url": "https://ads.google.com/intl/en/getstarted/"},
            {"title": "Full-funnel growth experiment", "level": "Advanced", "outcome": "Design and run an A/B test end to end.", "url": "https://cxl.com/blog/ab-testing-guide/"},
        ],
        "roadmap_titles": ["Marketing funnel refresh", "Analytics & KPI setup", "Design an A/B test",
                           "Paid acquisition basics", "Email & lifecycle automation", "Run a growth experiment",
                           "Report results & next steps", "Growth mock interview", "Review & consolidate"],
        "quiz_bank": [
            {"id": 1, "q": "In A/B testing, what should differ between the two versions?", "options": ["One variable", "Everything", "Nothing"], "answer": 0},
            {"id": 2, "q": "Which metric best measures ad spend efficiency?", "options": ["CPA", "Impressions", "Bounce rate"], "answer": 0},
            {"id": 3, "q": "What does CAC stand for?", "options": ["Customer acquisition cost", "Click and convert", "Cost of ad clicks"], "answer": 0},
            {"id": 4, "q": "What is a conversion funnel?", "options": ["The steps from visitor to customer", "A type of ad", "An email template"], "answer": 0},
            {"id": 5, "q": "Why does an A/B test need enough sample size?", "options": ["To reach statistically reliable results", "To make ads cheaper", "To speed up the site"], "answer": 0},
        ],
    },
    "Content Marketing Specialist": {
        "growth_skills": ["Content strategy", "Copywriting", "Editorial planning", "Storytelling"],
        "courses": [
            {"title": "Content Marketing Fundamentals", "platform": "YouTube", "duration": "2h 40m", "free": True, "url": _yt("content marketing fundamentals")},
            {"title": "Copywriting That Converts", "platform": "YouTube", "duration": "3h 00m", "free": True, "url": _yt("copywriting course for beginners")},
            {"title": "Content Strategy for Professionals", "platform": "Coursera", "duration": "5 weeks", "free": False, "url": _cs("content strategy")},
        ],
        "projects": [
            {"title": "Editorial calendar for 3 months", "level": "Beginner", "outcome": "Plan topics, formats and publishing cadence.", "url": "https://ahrefs.com/blog/content-calendar/"},
            {"title": "Long-form pillar article + cluster posts", "level": "Intermediate", "outcome": "Build a topic cluster that supports one flagship piece.", "url": "https://ahrefs.com/blog/topic-clusters/"},
            {"title": "Brand storytelling campaign", "level": "Advanced", "outcome": "Tell one story across blog, email and social.", "url": "https://contentmarketinginstitute.com/"},
        ],
        "roadmap_titles": ["Content marketing refresh", "Audience & persona research", "Copywriting fundamentals",
                           "Build an editorial calendar", "Write a pillar article", "Repurpose across channels",
                           "Measure content performance", "Content mock interview", "Review & consolidate"],
        "quiz_bank": [
            {"id": 1, "q": "What is a content pillar?", "options": ["A core topic that supports related posts", "A paid ad format", "A social media handle"], "answer": 0},
            {"id": 2, "q": "What does a strong headline do first?", "options": ["Earn the click by promising value", "List every keyword", "Describe the company"], "answer": 0},
            {"id": 3, "q": "Which metric best shows content engagement?", "options": ["Average time on page", "Server uptime", "Number of tags"], "answer": 0},
            {"id": 4, "q": "What is content repurposing?", "options": ["Adapting one piece into other formats", "Deleting old posts", "Buying backlinks"], "answer": 0},
            {"id": 5, "q": "What is a call to action (CTA)?", "options": ["A prompt telling readers the next step", "A page title", "An image caption"], "answer": 0},
        ],
    },
    "SEO Specialist": {
        "growth_skills": ["Keyword research", "Technical SEO", "Link building", "Google Search Console"],
        "courses": [
            {"title": "SEO for Beginners", "platform": "YouTube", "duration": "3h 30m", "free": True, "url": _yt("seo for beginners full course")},
            {"title": "Technical SEO Guide", "platform": "Docs", "duration": "2h 00m", "free": True, "url": "https://developers.google.com/search/docs/fundamentals/seo-starter-guide"},
            {"title": "Search Engine Optimization Specialization", "platform": "Coursera", "duration": "4 weeks", "free": False, "url": _cs("search engine optimization")},
        ],
        "projects": [
            {"title": "Keyword research for a niche site", "level": "Beginner", "outcome": "Find low-competition terms and group them by intent.", "url": "https://ahrefs.com/blog/keyword-research/"},
            {"title": "Technical SEO audit", "level": "Intermediate", "outcome": "Crawl a site and report indexing, speed and structure issues.", "url": "https://developers.google.com/search/docs/fundamentals/seo-starter-guide"},
            {"title": "Rank a new page from scratch", "level": "Advanced", "outcome": "Research, publish, build links and track rankings for 90 days.", "url": "https://ahrefs.com/blog/link-building/"},
        ],
        "roadmap_titles": ["How search engines work", "Keyword research & search intent", "On-page optimization",
                           "Technical SEO audit", "Link-building basics", "Track rankings in Search Console",
                           "Publish and optimize a page", "SEO mock interview", "Review & consolidate"],
        "quiz_bank": [
            {"id": 1, "q": "What is search intent?", "options": ["The goal behind a search query", "The number of searches", "A ranking penalty"], "answer": 0},
            {"id": 2, "q": "Which file tells crawlers which pages not to crawl?", "options": ["robots.txt", "sitemap.xml", "index.html"], "answer": 0},
            {"id": 3, "q": "What is a backlink?", "options": ["A link from another site to yours", "A broken page", "An internal menu"], "answer": 0},
            {"id": 4, "q": "Which tool shows how your site performs in Google search?", "options": ["Google Search Console", "Google Docs", "Google Maps"], "answer": 0},
            {"id": 5, "q": "What does a canonical tag do?", "options": ["Points to the preferred version of a page", "Speeds up images", "Adds a keyword"], "answer": 0},
        ],
    },
}
